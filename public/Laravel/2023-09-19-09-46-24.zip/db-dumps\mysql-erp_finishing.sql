
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `accounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `accounts` (
  `account_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `account_name` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `account_debit` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `account_qty` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `account_credit` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `account_category` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`account_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `accounts` WRITE;
/*!40000 ALTER TABLE `accounts` DISABLE KEYS */;
/*!40000 ALTER TABLE `accounts` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `buyer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `buyer` (
  `buyer_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `company_name` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company_email` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `credit` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `debit` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `buyer_type` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company_phone_number` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_person` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_person_phone` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_person_number` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `total_records` int(11) DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`buyer_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `buyer` WRITE;
/*!40000 ALTER TABLE `buyer` DISABLE KEYS */;
INSERT INTO `buyer` VALUES (1,'psoft','m.azharalamjawaid@gmail.com','0.00','1300','Customer','1','latifabad','03112495175','Azhar Alam',NULL,'Azhar Alam',0,'2023-09-14 22:40:51','2023-09-17 21:57:17'),(2,'psoft2','m.azharalamjawaid@gmail.com','0.00','800','Customer','2','latifabad','03112495175','Azhar Alam',NULL,'Azhar Alam',0,'2023-09-14 22:41:04','2023-09-17 21:55:46');
/*!40000 ALTER TABLE `buyer` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `customization`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customization` (
  `id` bigint(20) unsigned NOT NULL,
  `company_name` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `theme_color` varchar(199) COLLATE utf8mb4_unicode_ci NOT NULL,
  `text_color` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `text_hover_color` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `customization` WRITE;
/*!40000 ALTER TABLE `customization` DISABLE KEYS */;
/*!40000 ALTER TABLE `customization` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `model_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `model_has_permissions` (
  `permission_id` bigint(20) unsigned NOT NULL,
  `model_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `model_has_permissions` WRITE;
/*!40000 ALTER TABLE `model_has_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `model_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `model_has_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `model_has_roles` (
  `role_id` bigint(20) unsigned NOT NULL,
  `model_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `model_has_roles` WRITE;
/*!40000 ALTER TABLE `model_has_roles` DISABLE KEYS */;
/*!40000 ALTER TABLE `model_has_roles` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `organization`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `organization` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `organization_name` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone_number` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `logo` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `organization` WRITE;
/*!40000 ALTER TABLE `organization` DISABLE KEYS */;
INSERT INTO `organization` VALUES (1,'PSOFT','PAKISTAN','psoft@yourdomain.com','92123455667','org_logo/gdar1NquQpPxBCWjPuegmb5J93apnRDd0FNeP77u.jpg',NULL,'2023-09-19 16:44:33');
/*!40000 ALTER TABLE `organization` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `payment_voucher`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payment_voucher` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `unique_id` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `item` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `rate_type` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `vehicle_no` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `crate_type` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `crate_qty` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `hen_qty` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gross_weight` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `actual_rate` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `feed_cut` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mor_cut` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `crate_cut` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `avg` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `n_weight` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `rate_diff` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `rate` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `amount` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sales_officer` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remark` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pkr_amount` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bilty_no` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `warehouse` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `unit` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `batch_no` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `expiry` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pur_qty` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `price` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `expense_amount` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `discount` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `exp_unit` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dis_amount` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `due_date` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `s_party` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `transporter` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sales_price` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sales_qty` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bonus_qty` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pur_price` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sale_price` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sale_qty` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `book` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `previous_balance` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cartage` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `grand_total` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `amount_paid` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `balance_amount` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `qty_total` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dis_total` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `amount_total` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_method` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `account` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `previous_customer_id` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `previous_customer_debit` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `previous_customer_credit` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `avail_stock` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `previous_stock` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `invoice_no` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `freight` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sales_tax` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ad_sales_tax` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `banka` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `other_expensea` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bank` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `other_expense` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `freighta` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sales_taxa` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ad_sales_taxa` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pr_item` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `narration` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cheque_no` int(11) DEFAULT NULL,
  `cheque_date` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cash_bank` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ref_no` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `payment_voucher` WRITE;
/*!40000 ALTER TABLE `payment_voucher` DISABLE KEYS */;
INSERT INTO `payment_voucher` VALUES (4,'2023-09-17 21:59:15','2023-09-17 21:59:15','PV2221',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1000.00',NULL,NULL,'2023-09-17',NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'3000',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'testing',23,'2023-09-17',NULL,'23'),(5,'2023-09-17 21:59:15','2023-09-17 21:59:15','PV2221',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1000.00',NULL,NULL,'2023-09-17',NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'3000',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'4341',32,NULL,NULL,'23'),(6,'2023-09-17 21:59:15','2023-09-17 21:59:15','PV2221',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1000.00',NULL,NULL,'2023-09-17',NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'3000',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2323',23,NULL,NULL,'23');
/*!40000 ALTER TABLE `payment_voucher` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permissions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `permissions_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `personal_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `personal_access_tokens` WRITE;
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `product_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_category` (
  `product_category_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `category_name` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`product_category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `product_category` WRITE;
/*!40000 ALTER TABLE `product_category` DISABLE KEYS */;
INSERT INTO `product_category` VALUES (1,'pc11','2023-09-14 22:44:36','2023-09-14 22:44:47'),(2,'pc22','2023-09-14 22:44:41','2023-09-14 22:44:53');
/*!40000 ALTER TABLE `product_category` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `product_company`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_company` (
  `product_company_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `company_name` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`product_company_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `product_company` WRITE;
/*!40000 ALTER TABLE `product_company` DISABLE KEYS */;
INSERT INTO `product_company` VALUES (1,'psoft11','2023-09-14 22:45:17','2023-09-14 22:45:29'),(2,'psoft22','2023-09-14 22:45:23','2023-09-14 22:45:36');
/*!40000 ALTER TABLE `product_company` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `product_sub_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_sub_category` (
  `product_sub_category_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `sub_category_name` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `main_category` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`product_sub_category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `product_sub_category` WRITE;
/*!40000 ALTER TABLE `product_sub_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_sub_category` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `product_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_type` (
  `product_type_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `type` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`product_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `product_type` WRITE;
/*!40000 ALTER TABLE `product_type` DISABLE KEYS */;
INSERT INTO `product_type` VALUES (1,'psoft11','2023-09-14 22:45:49','2023-09-14 22:46:02'),(2,'psoft2','2023-09-14 22:45:56','2023-09-14 22:45:56');
/*!40000 ALTER TABLE `product_type` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `products` (
  `product_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `desc` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `unit` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `product_type` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `category` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `purchase_price` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `product_sale_price` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `opening_pur_price` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `opening_quantity` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `avg_pur_price` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `overhead_exp` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `overhead_price_pur` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `overhead_price_avg` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pur_price_plus_oh` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `avg_price_plus_oh` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `inactive_item` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `barcode` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `product_name` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `re_order_level` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`product_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES (1,'Finishing Test','100','2','2','2','100','100','100','-40','100','100','100','100','100','100','100','100','Finishing Test','100','product_img/s1xzS5Au0H156Uoqj2NNrJbuRPbeTQAJTTnolexu.jpg',NULL,'2023-09-14 22:47:11','2023-09-17 22:01:37'),(6,NULL,NULL,'1','1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'HICOS 5 Liter',NULL,'product_img/RHOPJXlm5IC9P8eQD2PcVUYd7LbgNFnTFXQH1HNU.png',NULL,'2023-09-19 16:45:53','2023-09-19 16:45:53');
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `purchase_invoice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `purchase_invoice` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `unique_id` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `item` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `rate_type` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `vehicle_no` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `crate_type` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `crate_qty` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `hen_qty` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gross_weight` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `actual_rate` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `feed_cut` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mor_cut` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `crate_cut` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `avg` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `n_weight` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `rate_diff` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `rate` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `amount` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sales_officer` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remark` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pkr_amount` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bilty_no` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `warehouse` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `unit` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `batch_no` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `expiry` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pur_qty` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `price` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `expense_amount` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `discount` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `exp_unit` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dis_amount` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `due_date` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `s_party` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `transporter` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sales_price` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sales_qty` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bonus_qty` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pur_price` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sale_price` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sale_qty` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `book` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `previous_balance` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cartage` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `grand_total` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `amount_paid` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `balance_amount` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `qty_total` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dis_total` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `amount_total` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_method` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `account` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `previous_customer_id` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `previous_customer_debit` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `previous_customer_credit` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `avail_stock` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `previous_stock` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `invoice_no` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `freight` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sales_tax` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ad_sales_tax` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `banka` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `other_expensea` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bank` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `other_expense` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `freighta` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sales_taxa` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ad_sales_taxa` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pr_item` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `purchase_invoice` WRITE;
/*!40000 ALTER TABLE `purchase_invoice` DISABLE KEYS */;
INSERT INTO `purchase_invoice` VALUES (17,'PI-2345','1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'900',NULL,NULL,'2023-09-17',NULL,NULL,'1','1',NULL,'2023-09-17 22:01:37','2023-09-17 22:01:37','100',NULL,NULL,'10',NULL,NULL,'10','0.00','100',NULL,NULL,NULL,NULL,NULL,NULL,'100',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'10','100','1063.8',NULL,NULL,NULL,NULL,NULL,NULL,'10',NULL,'0.00','0.2','18',NULL,NULL,'0.00','0.00',NULL,NULL,NULL,'1');
/*!40000 ALTER TABLE `purchase_invoice` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `receipt_vouchers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `receipt_vouchers` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `unique_id` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `ref_no` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company_ref` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sales_officer` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `s-party` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `invoice_no` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remark` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `narration` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cheque_no` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cheque_date` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cash_bank` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `amount` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `amount_total` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=87 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `receipt_vouchers` WRITE;
/*!40000 ALTER TABLE `receipt_vouchers` DISABLE KEYS */;
INSERT INTO `receipt_vouchers` VALUES (82,'RV5023',NULL,'2023-09-17','1','B','1',NULL,'155',NULL,'testing','12',NULL,NULL,'100.00','200','2023-09-17 21:48:27','2023-09-17 21:48:27'),(83,'RV5023',NULL,'2023-09-17','1','B','1',NULL,'155',NULL,'testing 2',NULL,NULL,NULL,'100.00','200','2023-09-17 21:48:27','2023-09-17 21:48:27'),(84,'RV177','32','2023-09-17','1','B','1',NULL,'161',NULL,'testing','32',NULL,NULL,'100.00','200','2023-09-17 21:57:17','2023-09-17 21:57:17'),(85,'RV177','32','2023-09-17','1','B','1',NULL,'163',NULL,'23','23',NULL,NULL,'100.00','200','2023-09-17 21:57:17','2023-09-17 21:57:17'),(86,'RV177','32','2023-09-17','1','B','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0.00','200','2023-09-17 21:57:18','2023-09-17 21:57:18');
/*!40000 ALTER TABLE `receipt_vouchers` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `role_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role_has_permissions` (
  `permission_id` bigint(20) unsigned NOT NULL,
  `role_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`role_id`),
  KEY `role_has_permissions_role_id_foreign` (`role_id`),
  CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `role_has_permissions` WRITE;
/*!40000 ALTER TABLE `role_has_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `role_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roles` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `roles_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `sales_officer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sales_officer` (
  `sales_officer_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `sales_officer_name` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone_number` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`sales_officer_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `sales_officer` WRITE;
/*!40000 ALTER TABLE `sales_officer` DISABLE KEYS */;
INSERT INTO `sales_officer` VALUES (1,'Azhar  (Sales Officer) 11','03112495175','m.azharalamjawaid@gmail.com','2023-09-14 22:42:58','2023-09-14 22:43:15'),(2,'Azhar  (Sales Officer) 22','03112495175','m.azharalamjawaid@gmail.com','2023-09-14 22:43:09','2023-09-14 22:43:20');
/*!40000 ALTER TABLE `sales_officer` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `sell_invoice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sell_invoice` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `unique_id` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `rate_type` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `vehicle_no` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `crate_type` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `crate_qty` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `hen_qty` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gross_weight` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `actual_rate` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `feed_cut` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mor_cut` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `crate_cut` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `avg` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `n_weight` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `rate_diff` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `rate` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `amount` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sales_officer` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remark` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pkr_amount` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bilty_no` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `warehouse` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `unit` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `batch_no` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `expiry` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pur_qty` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `price` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `expense_amount` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `discount` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dis_amount` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `exp_unit` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `due_date` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `s_party` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `transporter` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sales_price` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sales_qty` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bonus_qty` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `item` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pur_price` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sale_price` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sale_qty` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `book` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `previous_balance` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cartage` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `grand_total` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `amount_paid` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `balance_amount` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `previous_balance_amount` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `qty_total` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dis_total` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `amount_total` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `account` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cash_method` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `previous_stock` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pr_item` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `return_qty` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=165 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `sell_invoice` WRITE;
/*!40000 ALTER TABLE `sell_invoice` DISABLE KEYS */;
INSERT INTO `sell_invoice` VALUES (161,'SI-954',NULL,'2023-09-17 21:51:38','2023-09-17 21:57:17',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'900','1',NULL,'2023-09-17',NULL,NULL,'2','1',NULL,'100',NULL,NULL,NULL,NULL,NULL,'10','100','0.00',NULL,NULL,NULL,NULL,NULL,'0.00','1',NULL,'100','10',NULL,'700','0.00','1600','200','1400','1400','10','100','900',NULL,NULL,'10','1',NULL),(163,'SI-2178',NULL,'2023-09-17 21:46:31','2023-09-17 21:57:17',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1000','1',NULL,'2023-09-17',NULL,NULL,'1','1',NULL,'100',NULL,NULL,NULL,NULL,NULL,'0.00','0','0.00',NULL,NULL,NULL,NULL,NULL,'0.00','1',NULL,'100','10',NULL,'0.00','0.00','1000','400','600','600','10','0','1000',NULL,NULL,'10','1',NULL),(164,'SI-9596',NULL,'2023-09-17 21:47:12','2023-09-17 21:55:46',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'900','1',NULL,'2023-09-17',NULL,NULL,'1','2',NULL,'100',NULL,NULL,NULL,NULL,NULL,'10','100','0.00',NULL,NULL,NULL,NULL,NULL,'0.00','1',NULL,'100','10',NULL,'0.00','0.00','900','100.00','800','800','10','100','900',NULL,NULL,'10','1',NULL);
/*!40000 ALTER TABLE `sell_invoice` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `seller`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `seller` (
  `seller_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `company_name` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `company_email` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company_phone_number` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `credit` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `debit` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `seller_type` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_person` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_person_number` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `total_records` text COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `address` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`seller_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `seller` WRITE;
/*!40000 ALTER TABLE `seller` DISABLE KEYS */;
INSERT INTO `seller` VALUES (1,'psoft','m.azharalamjawaid@gmail.com','03112495175','0.00','1936.6699999999998','supplier','hyderabd','Azhar Alam','Azhar Alam','0','latifabad','2023-09-14 22:41:44','2023-09-17 22:01:37'),(2,'psoft2','m.azharalamjawaid@gmail.com','03112495175','0.00','0.00','supplier','hyderabd','Azhar Alam','Azhar Alam','0','latifabad','2023-09-14 22:42:02','2023-09-14 22:42:02');
/*!40000 ALTER TABLE `seller` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `user_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone_number` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role` varchar(31) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `access` varchar(11) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'access',
  `no_records` int(11) NOT NULL DEFAULT 0,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `setup_permission` text COLLATE utf8mb4_unicode_ci DEFAULT 'on',
  `finance_permission` text COLLATE utf8mb4_unicode_ci DEFAULT 'on',
  `report_permission` text COLLATE utf8mb4_unicode_ci DEFAULT 'on',
  `product_permission` text COLLATE utf8mb4_unicode_ci DEFAULT 'on',
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `theme` text COLLATE utf8mb4_unicode_ci DEFAULT 'green',
  `last_seen` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `users_email_unique` (`email`),
  KEY `email_verified_at` (`email_verified_at`),
  KEY `email_verified_at_2` (`email_verified_at`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'admin',NULL,NULL,'admin','access',22,'admin','on','on','on','on',NULL,NULL,'green','2023-09-02 11:52:35',NULL,'2023-09-17 22:01:36'),(2,'admin2','m.azharalamjawaid@gmail.com','03112495175','admin','access',3,'admin','on','on','on','on',NULL,NULL,'green',NULL,'2023-09-08 18:54:14','2023-09-14 20:48:40'),(3,'admin3','m.azharalamjawaid@gmail.com3','031124951753','user','access',0,'admin','all',NULL,NULL,NULL,NULL,NULL,'green',NULL,'2023-09-14 20:47:07','2023-09-14 22:44:04');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `warehouse`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `warehouse` (
  `warehouse_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `warehouse_name` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `zone` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`warehouse_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `warehouse` WRITE;
/*!40000 ALTER TABLE `warehouse` DISABLE KEYS */;
INSERT INTO `warehouse` VALUES (1,'Test1','2','2023-09-14 22:42:21','2023-09-14 22:42:40'),(2,'Test2','2','2023-09-14 22:42:29','2023-09-14 22:42:29');
/*!40000 ALTER TABLE `warehouse` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `zone`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `zone` (
  `zone_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `zone_name` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`zone_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `zone` WRITE;
/*!40000 ALTER TABLE `zone` DISABLE KEYS */;
INSERT INTO `zone` VALUES (1,'Islamabad','2023-09-14 22:40:35','2023-09-14 22:40:35'),(2,'Lahore','2023-09-14 22:40:41','2023-09-14 22:40:41');
/*!40000 ALTER TABLE `zone` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

