 <?php $__env->startSection('content'); ?>

<br><br><br><br><br>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <!-- DATA TABLE -->
            <h3 class="title-5 m-b-35">User table</h3>
            <div class="table-data__tool">
                <div class="table-data__tool-left">
                <form class="form-inline d-flex justify-content-center md-form form-sm mt-0">
                        <button type="submit"><i class="fas fa-search" aria-hidden="true"></i></button>
                        <input class="form-control  form-control-sm ml-3 w-75" type="search" name="search" id="search" placeholder="Search" aria-label="Search" value="<?php echo e($search ?? ''); ?>">
                    </form>
                    

                </div>
                <div class="table-data__tool-right">
                    <a href="/add-user" class="au-btn au-btn-icon au-btn--green au-btn--small">
                        <i class="zmdi zmdi-plus"></i>add user</a>
                    <div class="rs-select2--dark rs-select2--sm rs-select2--dark2">
                    <div class="rs-select2--dark rs-select2--sm rs-select2--dark2">
                            <button href="" data-toggle="modal" data-target="#p-user" class="btn btn-primary" role="button" style="background-color: #666;border:1px solid gray; outline:1px solid gray;">Export</button>
                        </div>
                    </div>
                </div>
            </div>
            <div class="table-responsive table-responsive-data2">
                <table class="table table-data2">
                    <thead>
                        <tr>
                            <th>S.No</th>
                            <th>name</th>
                            <th>role</th>
                            <th>Access</th>
                            <th>no.records</th>
                            <th>Created At</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $serial = ($users->currentPage() - 1) * $users->perPage() + 1;;
                        ?>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                        <tr class="tr-shadow">
                            <td>
                                <?php echo e($serial); ?>

                            </td>
                            <td><?php echo e($row->username); ?></td>
                            <td>
                                <span class="status--process"><?php echo e($row->role); ?></span>
                            </td>
                            <?php if($row->access != 'access'): ?>
                            <td>
                                <span class="badge badge-danger"><?php echo e($row->access); ?></span>
                            </td>

                            <?php else: ?>
                            <td>
                                <span class="badge badge-success"><?php echo e($row->access); ?></span>
                            </td>
                            <?php endif; ?>

                            <td><a href="/user-records-<?php echo e($row->user_id); ?>"><span class="block-email"><?php echo e($row->no_records); ?></span></a></td>
                            <td><?php echo e($row->created_at); ?></td>

                            <td>
                                <div class="table-data-feature">

                                    <a href="/edit-user-<?php echo e($row->user_id); ?>" class="item" data-toggle="tooltip" data-placement="top" title="" data-original-title="Edit">
                                        <i class="zmdi zmdi-edit"></i>
                                    </a>
                                    <a href="/user-rights-<?php echo e($row->user_id); ?>" class="item" data-toggle="tooltip" data-placement="top" title="" data-original-title="Manage rights">
                                        <i class="fa fa-universal-access"></i>
                                    </a>

                                    <!-- <a href="/del_user<?php echo e($row->user_id); ?>" class="item" data-toggle="tooltip" data-placement="top" title="" data-original-title="Delete User">
                                <i class="fa fa-trash"></i>
                            
                            </a> -->

                                </div>
                            </td>
                        </tr>
                        <!-- <tr class="spacer"></tr> -->
                        <?php
                        $serial++;
                        ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                </table>
            </div>
            <div class="container">
                <?php echo e($users->appends(['search' => $search])->links()); ?>

            </div>

            <!-- END DATA TABLE -->
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\code1\xampp\htdocs\ER-PROJECT\resources\views/users.blade.php ENDPATH**/ ?>