<?php
// Retrieve data directly in Blade
$account = \App\Models\accounts::all();
$warehouse = \App\Models\warehouse::all();
$sales_officer = \App\Models\sales_officer::all();

$customer = \App\Models\buyer::all();

?>


<?php if(session('message') != ''): ?>

<div class="flex justify-center items-center">
    <div class="sufee-alert alert with-close alert-success alert-dismissible fade show text-center custom-alert" style="position: fixed; top: 85%; left: 50%; transform: translate(-50%, -50%); width: 32%; opacity: 0.85;">
        <?php echo e(session('message')); ?>

        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">×</span>
        </button>
    </div>
</div>




<?php endif; ?>

<?php if(session('something_error') != ''): ?>

<div class="flex justify-center items-center">
    <div class="sufee-alert alert with-close alert-danger alert-dismissible fade show text-center custom-alert" style="position: fixed; top: 85%; left: 50%; transform: translate(-50%, -50%); width: 32%; opacity: 0.75;">
        <?php echo e(session('something_error')); ?>

        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">×</span>
        </button>
    </div>
</div>

<?php endif; ?>

<br><br><br><br><br><br>
<div class="row" style="align-items: center;">
    <div class="col-md-12">
        <div class="copyright">
            <p>Copyright © 2023 <a href="https://psofts.online" style="color: green;">www.psofts.online</a> All rights reserved. Template by <a href="https://colorlib.com">Colorlib</a>.</p>
        </div>
    </div>
</div>




<!-- href="" data-toggle="modal" data-target="#login-modal" -->




<div class="modal fade" id="p-user">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-body">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4>Export</h4>
                <div class="modal-body">
                    <form method="GET" action="/pdf_limitusers">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="username">No. Records</label>
                            <input type="number" min="1" class="form-control" id="type" name="limit" required value="">
                        </div>

                        <button type="submit" target class="btn btn-primary" id="btn">Submit</button>
                        <a type="button" class="btn btn-primary" style="background-color:black;" id="btn" href="/pdf_field=users">PDF All</a>

                    </form>
                </div>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div>





<div class="modal fade" id="p-supplier">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-body">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4>Export</h4>
                <div class="modal-body">
                    <form method="GET" action="/pdf_limitsupplier">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="username">No. Records</label>
                            <input type="number" min="1" class="form-control" id="type" name="limit" required value="">
                        </div>

                        <button type="submit" class="btn btn-primary" id="btn">Submit</button>
                        <a type="button" class="btn btn-primary" style="background-color:black;" id="btn" href="/pdf_field=supplier">PDF All</a>

                    </form>
                </div>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div>





<div class="modal fade" id="p-buyer">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-body">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4>Export</h4>
                <div class="modal-body">
                    <form method="GET" action="/pdf_limitbuyer">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="username">No. Records</label>
                            <input type="number" min="1" class="form-control" id="type" name="limit" required value="">
                        </div>

                        <button type="submit" class="btn btn-primary" id="btn">Submit</button>
                        <a type="button" class="btn btn-primary" style="background-color:black;" id="btn" href="/pdf_field=buyer">PDF All</a>

                    </form>
                </div>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div>




<div class="modal fade" id="p-zone">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-body">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4>Export</h4>
                <div class="modal-body">
                    <form method="GET" action="/pdf_limitzone">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="username">No. Records</label>
                            <input type="number" min="1" class="form-control" id="type" name="limit" required value="">
                        </div>

                        <button type="submit" class="btn btn-primary" id="btn">Submit</button>
                        <a type="button" class="btn btn-primary" style="background-color:black;" id="btn" href="/pdf_field=zone">PDF All</a>

                    </form>
                </div>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div>




<div class="modal fade" id="p-warehouse">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-body">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4>Export</h4>
                <div class="modal-body">
                    <form method="GET" action="/pdf_limitwarehouse">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="username">No. Records</label>
                            <input type="number" min="1" class="form-control" id="type" name="limit" required value="">
                        </div>

                        <button type="submit" class="btn btn-primary" id="btn">Submit</button>
                        <a type="button" class="btn btn-primary" style="background-color:black;" id="btn" href="/pdf_field=warehouse">PDF All</a>

                    </form>
                </div>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div>







<div class="modal fade" id="p-sales_officer">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-body">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4>Export</h4>
                <div class="modal-body">
                    <form method="GET" action="/pdf_limitsales_officer">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="username">No. Records</label>
                            <input type="number" min="1" class="form-control" id="type" name="limit" required value="">
                        </div>

                        <button type="submit" class="btn btn-primary" id="btn">Submit</button>
                        <a type="button" class="btn btn-primary" style="background-color:black;" id="btn" href="/pdf_field=sales_officer">PDF All</a>

                    </form>
                </div>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div>


<?php

$id = session()->get("user_id")['user_id'];
$theme_colors = App\Models\users::where("user_id", $id)->get();

foreach ($theme_colors as $key => $value2) {

$theme_color = $value2->theme;
}

?>

?>
<div class="modal fade" id="customize">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-body">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4>Customize Theme</h4>
                <div class="modal-body">
                    <form method="POST" action="/customize-form">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="username">Theme</label>
                            <input type="color" class="form-control" name="theme_color" style="min-height:10vh;" value="<?php echo e($theme_color); ?>">
                        </div>

                        <button type="submit" class="btn btn-primary" id="btn">Submit</button>

                    </form>
                </div>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div>

<style>
    @media (max-width: 755px) {

        .gen-led {
            width: auto !important;
            margin-left: auto !important;
            height: auto !important;

        }

    }

    .gen-led {
        width: 150%;
        margin-left: -28%;
        height: 70vh;
    }
</style>

<div class="modal fade" id="gen-led">
    <div class="modal-dialog">
        <div class="modal-content gen-led">
            <div class="modal-body">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4>General Ledger</h4>
                <div class="modal-body">
                    <form method="GET" action="/gen-led">
                        <?php echo csrf_field(); ?>
                        <div class="row" style="justify-content: space-between;">

                            <div class="col-md-4">
                                <div class="form-group">
                                    <label>Head Of Account</label>
                                    <select class="form-control" name="head_account" id="head_account" onchange="accountData()">
                                        <option></option>
                                        <option value="1" data-id="1">Cash</option>
                                        <option value="2" data-id="2">Accounts Receivable</option>
                                        <option value="3" data-id="3">Accounts Payable</option>

                                    </select>
                                </div>
                            </div>

                            <div class="col-md-4">

                                <div class="form-group">
                                    <label>Account</label>
                                    <label for=""></label>
                                    <select class="form-control" name="account" id="gen-led-account">
                                        <option></option>

                                    </select>
                                </div>
                            </div>

                            <div class="col-md-4">

                                <div class="form-group">
                                    <label>Sales Officer</label>
                                    <label for=""></label>
                                    <select class="form-control" name="sales_officer">
                                        <option></option>
                                        <?php $__currentLoopData = $sales_officer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($row->sales_officer_id); ?>"><?php echo e($row->sales_officer_name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>


                            <div class="col-md-4">
                                <div class="form-group">
                                    <label>Company Type</label>
                                    <label for=""></label>
                                    <select class="form-control" name="company_type">
                                        <option></option>

                                    </select>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label>Zone</label>
                                    <label for=""></label>
                                    <select class="js-example-basic-multiple js-states form-control" name="warehouse">
                                        <option></option>
                                        <?php $__currentLoopData = $warehouse; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($row->warehouse_id); ?>"><?php echo e($row->warehouse_name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>

                        </div>

                        <div class="row" style="    justify-content: space-between;
margin-top:12%;
text-align: center;
">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="">From:</label>

                                    <input type="date" name="start_date" id="" required>
                                </div>

                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="">To:</label>
                                    <input type="date" name="end_date" id="" required>
                                </div>
                            </div>
                        </div>
                </div>
                <div class="submit" style="
    text-align: center;
    margin-top: 3.5%;
">
                    <button type="submit" class="btn btn-primary" id="btn">Submit</button>
                </div>
                </form>
            </div>
        </div>
    </div><!-- /.modal-content -->
</div><!-- /.modal-dialog -->
</div>



<div class="modal fade" id="cus-led">
    <div class="modal-dialog">
        <div class="modal-content gen-led">
            <div class="modal-body">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4>Customer Ledger</h4>
                <div class="modal-body">
                    <form method="GET" action="/cus-led">
                        <?php echo csrf_field(); ?>
                        <div class="row" style="justify-content: space-between;">

                            <div class="col-md">
                                <div class="form-group">
                                    <label>Select Customer</label>
                                    <select class="form-control" name="customer" id="customer">
                                        <option></option>
                                        <?php $__currentLoopData = $customer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($row->buyer_id); ?>"><?php echo e($row->company_name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </select>
                                </div>
                            </div>

                        </div>

                        <div class="row" style="    justify-content: space-between;
margin-top:12%;
text-align: center;
">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="">From:</label>

                                    <input type="date" name="start_date" id="" required>
                                </div>

                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="">To:</label>
                                    <input type="date" name="end_date" id="" required>
                                </div>
                            </div>
                        </div>
                </div>
                <div class="submit" style="
    text-align: center;
    margin-top: 3.5%;
">
                    <button type="submit" class="btn btn-primary" id="btn">Submit</button>
                </div>
                </form>
            </div>
        </div>
    </div><!-- /.modal-content -->
</div><!-- /.modal-dialog -->
</div>


<script>
    // if ($('#gen-led').hasClass('show')) {

    //     $('.form-control').select2({})
    // }    

    //         $('#gen-led').hide()

    $(document).ready(function() {
        $('select').select2({
            theme: 'default',
            width: 'resolve',
        });
    });
</script>

<div class="modal fade" id="p-return">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-body">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4>Export</h4>
                <div class="modal-body">
                    <form method="GET" action="">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="username">GR No</label>
                            <input type="number" min="1" class="form-control" id="invoice" name="limit" required value="">
                        </div>

                        <button type="button" class="btn btn-primary" id="btn" onclick="invoice()">Submit</button>

                    </form>
                    <script>
                        function invoice() {
                            let v = $("#invoice").val()

                            window.location.href = '/rp_med_invoice_form_id=' + v
                        }
                    </script>
                </div>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div>

<script>
    function pdf(field) {

        var href = field;
        window.location.href = "/pdf" + href
    }



    function accountData() {
        var company = $("#head_account").find('option:selected');
        var id = company.data('id')

        $("#head_account").on('change', function() {

            let invoice = $("#gen-led-account").find('option:selected').val('');
            let invoiceText = $("#gen-led-account").find('option:selected').text('');

        })

        console.log('it is id ' + id);
        $(document).ready(function() {
            $('#gen-led-account').select2({
                ajax: {
                    url: '/get-data/account',
                    dataType: 'json',
                    data: {
                        'id': id
                    },
                    delay: 250,
                    processResults: function(data) {

                        // console.log(data.data);          
                        return {
                            results: $.map(data, function(item) {
                                return {
                                    id: item.account_id,
                                    text: item.account_name
                                };
                            })
                        }

                    },
                    cache: true
                },
            });
        });

    }
</script>
<!-- Jquery JS-->
<script src="vendor/jquery-3.2.1.min.js"></script>
<!-- Bootstrap JS-->
<script src="vendor/bootstrap-4.1/popper.min.js"></script>
<script src="vendor/bootstrap-4.1/bootstrap.min.js"></script>
<!-- Vendor JS       -->
<script src="vendor/slick/slick.min.js">
</script>
<script src="vendor/wow/wow.min.js"></script>
<script src="vendor/animsition/animsition.min.js"></script>
<script src="vendor/bootstrap-progressbar/bootstrap-progressbar.min.js">
</script>
<script src="vendor/counter-up/jquery.waypoints.min.js"></script>
<script src="vendor/counter-up/jquery.counterup.min.js">
</script>
<script src="vendor/circle-progress/circle-progress.min.js"></script>
<script src="vendor/perfect-scrollbar/perfect-scrollbar.js"></script>
<script src="vendor/chartjs/Chart.bundle.min.js"></script>
<script src="vendor/select2/select2.min.js">
</script>

<!-- Main JS-->
<script src="js/main.js"></script>

<!-- Latest compiled and minified CSS -->

<!-- Latest compiled and minified JavaScript -->

<script>
    function user_check_access() {


        $.ajaxSetup({
            headers: {
                "X-CSRF-TOKEN": $('meta[name="csrf-token"]').attr("content"),
            },
        });


        // Get the form data

        // Send an AJAX request
        $.ajax({
            url: '/user-access', // Replace with your Laravel route or endpoint
            method: 'POST',
            success: function(response) {
                // Handle the response
                console.log(response);
                if (response == false) {
                    window.location.href = '/'
                } else {

                }

            },
            error: function(error) {
                // Handle the error
            },
        });
    }


    $(document).click(function() {

        user_check_access();
    })
    $(document).change(function() {

        user_check_access();
    })
    $(document).focus(function() {

        user_check_access();
    })
</script><?php /**PATH D:\code1\xampp\htdocs\ER-PROJECT\resources\views/foot.blade.php ENDPATH**/ ?>