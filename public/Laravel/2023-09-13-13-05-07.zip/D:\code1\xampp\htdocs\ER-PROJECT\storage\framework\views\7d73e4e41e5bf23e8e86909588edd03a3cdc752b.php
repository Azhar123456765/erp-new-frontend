 <?php $__env->startSection('content'); ?>

<br><br><br><br><br>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <!-- DATA TABLE -->
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <h3 class="title-5 m-b-35"><?php echo e($row->username); ?> Records</h3>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>           
            <div class="table-responsive table-responsive-data2">
                <table class="table table-data2">
                    <thead>
                        <tr>
                            <th>S.No</th>
                            <th>title</th>
                            <th>Invoice No</th>
                            <th>Amount</th>
                            <th>Created At</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $serial = 1;
                        ?>
                        <?php $__currentLoopData = $sale_invoice; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                        <tr class="tr-shadow">
                            <td>
                                <?php echo e($serial); ?>

                            </td>
                            <td><a href="/es_med_invoice_id=<?php echo e($row->unique_id); ?>"><span class="block-email">Sale Invoice</span></a></td>
                            <td><a href="/es_med_invoice_id=<?php echo e($row->unique_id); ?>"><span class="block-email"><?php echo e($row->unique_id); ?></span></a></td>
                            <td>
                                <span class="status--process"><?php echo e($row->balance_amount); ?></span>
                            </td>
                            <td><?php echo e($row->created_at); ?></td>
                            <td>
                                <div class="table-data-feature">
                                    <a href="/es_med_invoice_id=<?php echo e($row->unique_id); ?>" class="item" data-toggle="tooltip" data-placement="top" title="" data-original-title="Edit">
                                        <i class="zmdi zmdi-edit"></i>
                                    </a>
                                    <a href="/sale_invoice_pdf_<?php echo e($row->unique_id); ?>" class="item" data-toggle="tooltip" data-placement="top" title="" data-original-title="PDF">
                                        <i class="fa fa-solid fa-file-pdf"></i>
                                    </a>
                                </div>
                            </td>
                        </tr>
                        <?php
                        $serial++;
                        ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <?php $__currentLoopData = $purchase_invoice; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="tr-shadow table">
                            <td><?php echo e($serial); ?></td>
                            <td><a href="/ep_med_invoice_id=<?php echo e($row->unique_id); ?>"><span class="block-email">Purchase Invoice</span></a></td>
                            <td><a href="/ep_med_invoice_id=<?php echo e($row->unique_id); ?>"><span class="block-email"><?php echo e($row->unique_id); ?></span></a></td>
                            <td><span class="status--process"><?php echo e($row->amount_total); ?></span></td>
                            <td><?php echo e($row->created_at); ?></td>
                            <td>
                                <div class="table-data-feature">
                                    <a href="/ep_med_invoice_id=<?php echo e($row->unique_id); ?>" class="item" data-toggle="tooltip" data-placement="top" title="" data-original-title="Edit">
                                        <i class="zmdi zmdi-edit"></i>
                                    </a>
                                    <a href="/purchase_invoice_pdf_<?php echo e($row->unique_id); ?>" class="item" data-toggle="tooltip" data-placement="top" title="" data-original-title="PDF">
                                        <i class="fa fa-solid fa-file-pdf"></i>
                                    </a>
                                </div>
                            </td>
                        </tr>
                        <?php
                        $serial++;
                        ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <!-- END DATA TABLE -->
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\code1\xampp\htdocs\ER-PROJECT\resources\views/user-records.blade.php ENDPATH**/ ?>