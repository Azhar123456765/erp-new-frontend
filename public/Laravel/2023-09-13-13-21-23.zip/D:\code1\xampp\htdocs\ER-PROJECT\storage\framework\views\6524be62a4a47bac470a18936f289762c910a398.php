 <?php $__env->startSection('content'); ?>


<br><br><br>
<div class="container" style="width: 39%; margin-top:5%;">
    <h3>Edit user</h3>
    <div class="card-body card-block">


        <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <form action="/edit_user_form-<?php echo e($row->user_id); ?>" method="post">


            <?php echo csrf_field(); ?>

            <div class="form-group">
                <div class="input-group">
                    <input type="text" id="username2" name="username" placeholder="Username" class="form-control " required value="<?php echo e($row->username); ?>">
                    <div class="input-group-addon">
                        <i class="fa fa-user"></i>
                    </div>
                </div>
            </div>

            <div class="form-group">
                <div class="input-group">
                    <input type="email" id="email2" name="email" placeholder="Email" class="form-control " required value="<?php echo e($row->email); ?>">
                    <div class="input-group-addon">
                        <i class="fa fa-envelope"></i>
                    </div>
                </div>
            </div>
            <div class="form-group">
                <div class="input-group">
                    <input type="number" id="" name="phone_number" placeholder="phone number" class="form-control " required value="<?php echo e($row->phone_number); ?>">
                    <div class="input-group-addon">
                        <i class="fa fa-asterisk"></i>
                    </div>
                </div>
            </div>
            <div class="form-group">
                <div class="input-group">
                    <input type="text" id="password2" name="password" placeholder="Password" class="form-control " required value="<?php echo e($row->password); ?>">
                    <div class="input-group-addon">
                        <i class="fa fa-asterisk"></i>
                    </div>
                </div>
            </div>

            <div class="form-group">
                <label for="">Select Role</label>
                <select class="custom-select" name="role" id="" required>

                    <?php if($row->role == 'admin'): ?>
                    <option selected value="admin">admin</option>
                    <option value="user">user</option>
                    <?php else: ?>


                    <option value="admin">admin</option>
                    <option selected value="user">user</option>
                    <?php endif; ?>
                </select>
            </div>

            <input type="hidden" name="user_id" value="<?php echo e($row->user_id); ?>">

            <br>

            <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

            <div class="alert alert-danger" role="alert">
                <?php echo e($message); ?>




            </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

            <div class="alert alert-danger" role="alert">
                <?php echo e($message); ?>




            </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


            <?php $__errorArgs = ['phone_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

            <div class="alert alert-danger" role="alert">
                <?php echo e($message); ?>




            </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>



            <div class="form-actions form-group">
                <button type="submit" class="btn btn-secondary btn-sm">Submit</button>
            </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </form>
    </div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\code1\xampp\htdocs\ER-PROJECT\resources\views/edit_user.blade.php ENDPATH**/ ?>