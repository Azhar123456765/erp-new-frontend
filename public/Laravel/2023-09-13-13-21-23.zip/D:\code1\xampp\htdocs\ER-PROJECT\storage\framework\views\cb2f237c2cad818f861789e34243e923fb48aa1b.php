 <?php $__env->startSection('content'); ?>
<style>
    @media (max-width:755px) {
        .container {
            width: 100% !important;
        }
    }
</style>
<br><br><br>
<div class="container" style="width: 39%;">
    <h3>Manage Right</h3>
    <div class="card-body card-block">
        <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <form action="/user_right_form-<?php echo e($row->user_id); ?>" method="post">
            <?php echo csrf_field(); ?>



            <h4>Permissions</h4>
            <br>
            <div class="row">


                <div class="form-group col-md-6">
                    <label for="">Setup</label>
                    <div class="row">
                        <div class="col-md-4">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" name="setup_permission" id="readPermission" <?php echo e($row->setup_permission == 'on' ? 'checked' : ''); ?>>

                                <label class="form-check-label" for="readPermission">
                                    Access
                                </label>
                            </div>
                        </div>

                    </div>
                </div>

                <div class="form-group col-md-6">
                    <label for="">Finance</label>
                    <div class="row">
                        <div class="col-md-4">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" name="finance_permission" id="readPermission" <?php echo e($row->finance_permission == 'on' ? 'checked' : ''); ?>>
                                <label class="form-check-label" for="readPermission">
                                    Access
                                </label>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="form-group col-md-6">
                    <label for="">Products</label>
                    <div class="row">
                        <div class="col-md-4">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" name="product_permission" id="readPermission" <?php echo e($row->product_permission == 'on' ? 'checked' : ''); ?>>
                                <label class="form-check-label" for="readPermission">
                                    Access
                                </label>
                            </div>
                        </div>

                    </div>
                </div>

                <div class="form-group col-md-6">
                    <label for="">Reports</label>
                    <div class="row">
                        <div class="col-md-4">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" name="report_permission" id="readPermission" <?php echo e($row->report_permission == 'on' ? 'checked' : ''); ?>>
                                <label class="form-check-label" for="readPermission">
                                    Access
                                </label>
                            </div>
                        </div>
                    </div>
                </div>


            </div>

            <input type="hidden" name="user_id" value="<?php echo e($row->user_id); ?>">



            <div class="form-group" required>
                <label for="">Manage Access</label>
                <select class="custom-select" name="access" id="">
                    <option <?php if ($row->access == 'access') {
                                echo 'selected';
                            }    ?> value="access">Access</option>
                    <option <?php if ($row->access == 'denied') {
                                echo 'selected';
                            }    ?> value="denied">Denied</option>

                </select>
            </div>

            <div class="form-group" required>
                <label for="">Select Role</label>
                <select class="custom-select" name="role" id="">
                    <option <?php if ($row->role == 'admin') {
                                echo 'selected';
                            }    ?> value="admin">admin</option>
                    <option <?php if ($row->role == 'user') {
                                echo 'selected';
                            }    ?> value="user">user</option>

                </select>
            </div>

            <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

            <div class="alert alert-danger" role="alert">
                <?php echo e($message); ?>




            </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

            <div class="alert alert-danger" role="alert">
                <?php echo e($message); ?>




            </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


            <?php $__errorArgs = ['phone_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

            <div class="alert alert-danger" role="alert">
                <?php echo e($message); ?>




            </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <div class="form-actions form-group">
                <button type="submit" class="btn btn-secondary btn-sm">Submit</button>
            </div>
        </form>
    </div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\code1\xampp\htdocs\ER-PROJECT\resources\views/user_right.blade.php ENDPATH**/ ?>