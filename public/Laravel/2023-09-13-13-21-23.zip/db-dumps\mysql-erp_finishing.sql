
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `accounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `accounts` (
  `account_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `account_name` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `account_debit` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `account_qty` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `account_credit` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `account_category` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`account_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `accounts` WRITE;
/*!40000 ALTER TABLE `accounts` DISABLE KEYS */;
INSERT INTO `accounts` VALUES (1,'Bank Al Falahq',NULL,NULL,NULL,'3','2023-09-07 19:17:58','2023-09-08 10:25:03'),(2,'Bank Al Fala1h',NULL,NULL,NULL,'2','2023-09-07 19:18:45','2023-09-07 19:25:37');
/*!40000 ALTER TABLE `accounts` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `buyer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `buyer` (
  `buyer_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `company_name` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company_email` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `credit` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `debit` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `buyer_type` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company_number` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_person` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_person_phone` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `AR_control` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_person_number` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `transporter` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reference_number` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bilty_number` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `salesman` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `total_records` int(11) DEFAULT 0,
  `payment_due_date` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`buyer_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `buyer` WRITE;
/*!40000 ALTER TABLE `buyer` DISABLE KEYS */;
INSERT INTO `buyer` VALUES (1,'psoft','m.azharalamjawaid@gmail.com','0.00','1800','Customer','hyderabd','latifabad',NULL,NULL,NULL,NULL,'Azhar Alam',NULL,NULL,NULL,NULL,0,NULL,'2023-09-08 01:44:41','2023-09-13 18:26:32'),(2,'psoft2','m.azharalamjawaid@gmail.com2','0.00','2600','Customer','hyderabd','latifabad',NULL,NULL,NULL,NULL,'Azhar Alam',NULL,NULL,NULL,NULL,0,NULL,'2023-09-08 01:45:04','2023-09-08 10:07:45');
/*!40000 ALTER TABLE `buyer` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `customization`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customization` (
  `id` bigint(20) unsigned NOT NULL,
  `company_name` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `theme_color` varchar(199) COLLATE utf8mb4_unicode_ci NOT NULL,
  `text_color` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `text_hover_color` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `customization` WRITE;
/*!40000 ALTER TABLE `customization` DISABLE KEYS */;
/*!40000 ALTER TABLE `customization` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (2,'2023_05_25_172515_customization',1),(3,'2023_05_25_172731_invoice',1),(6,'2019_12_14_000001_create_personal_access_tokens_table',2),(7,'2023_09_11_101425_create_permission_tables',2);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `model_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `model_has_permissions` (
  `permission_id` bigint(20) unsigned NOT NULL,
  `model_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `model_has_permissions` WRITE;
/*!40000 ALTER TABLE `model_has_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `model_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `model_has_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `model_has_roles` (
  `role_id` bigint(20) unsigned NOT NULL,
  `model_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `model_has_roles` WRITE;
/*!40000 ALTER TABLE `model_has_roles` DISABLE KEYS */;
/*!40000 ALTER TABLE `model_has_roles` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `organization`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `organization` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `organization_name` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone_number` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `logo` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `organization` WRITE;
/*!40000 ALTER TABLE `organization` DISABLE KEYS */;
INSERT INTO `organization` VALUES (1,'PSOFT','Hyderabad Latifabad, Pakistan','psoft@demo.com','123456789','org_logo/tKsPcSlFeXIysQczKAv4gtCJCSvzVGF528SJ68Sw.jpg',NULL,'2023-09-02 14:34:42');
/*!40000 ALTER TABLE `organization` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `payment_voucher`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payment_voucher` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `unique_id` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `item` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `rate_type` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `vehicle_no` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `crate_type` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `crate_qty` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `hen_qty` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gross_weight` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `actual_rate` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `feed_cut` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mor_cut` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `crate_cut` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `avg` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `n_weight` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `rate_diff` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `rate` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `amount` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sales_officer` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remark` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pkr_amount` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bilty_no` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `warehouse` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `unit` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `batch_no` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `expiry` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pur_qty` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `price` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `expense_amount` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `discount` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `exp_unit` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dis_amount` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `due_date` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `s_party` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `transporter` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sales_price` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sales_qty` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bonus_qty` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pur_price` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sale_price` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sale_qty` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `book` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `previous_balance` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cartage` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `grand_total` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `amount_paid` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `balance_amount` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `qty_total` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dis_total` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `amount_total` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_method` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `account` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `previous_customer_id` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `previous_customer_debit` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `previous_customer_credit` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `avail_stock` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `previous_stock` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `invoice_no` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `freight` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sales_tax` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ad_sales_tax` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `banka` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `other_expensea` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bank` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `other_expense` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `freighta` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sales_taxa` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ad_sales_taxa` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pr_item` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `narration` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cheque_no` int(11) DEFAULT NULL,
  `cheque_date` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cash_bank` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ref_no` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `payment_voucher` WRITE;
/*!40000 ALTER TABLE `payment_voucher` DISABLE KEYS */;
INSERT INTO `payment_voucher` VALUES (1,'2023-09-13 18:36:44','2023-09-13 18:36:44','PV2223',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1000.00',NULL,'34','2023-09-13',NULL,NULL,NULL,'1S',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1000',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'testing',21,'2023-09-13','2','32');
/*!40000 ALTER TABLE `payment_voucher` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permissions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `permissions_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `personal_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `personal_access_tokens` WRITE;
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `product_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_category` (
  `product_category_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `category_name` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`product_category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `product_category` WRITE;
/*!40000 ALTER TABLE `product_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_category` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `product_company`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_company` (
  `product_company_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `company_name` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`product_company_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `product_company` WRITE;
/*!40000 ALTER TABLE `product_company` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_company` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `product_sub_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_sub_category` (
  `product_sub_category_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `sub_category_name` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `main_category` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`product_sub_category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `product_sub_category` WRITE;
/*!40000 ALTER TABLE `product_sub_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_sub_category` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `product_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_type` (
  `product_type_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `type` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`product_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `product_type` WRITE;
/*!40000 ALTER TABLE `product_type` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_type` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `products` (
  `product_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `desc` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `unit` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `product_type` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `category` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `purchase_price` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `product_sale_price` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `opening_pur_price` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `opening_quantity` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `avg_pur_price` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `overhead_exp` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `overhead_price_pur` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `overhead_price_avg` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pur_price_plus_oh` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `avg_price_plus_oh` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `inactive_item` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `barcode` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `product_name` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `re_order_level` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`product_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES (1,'NULL','JAR',NULL,NULL,NULL,'10','10','10','-380','10','1','10',NULL,'01','10','10','1','DEMO',NULL,'product_img/SVDUUFLbWVWY3tBOKR5y5qbNALcFJGmpAOziU56u.jpg','1',NULL,'2023-09-13 18:38:27');
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `purchase_invoice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `purchase_invoice` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `unique_id` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `item` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `rate_type` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `vehicle_no` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `crate_type` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `crate_qty` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `hen_qty` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gross_weight` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `actual_rate` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `feed_cut` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mor_cut` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `crate_cut` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `avg` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `n_weight` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `rate_diff` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `rate` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `amount` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sales_officer` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remark` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pkr_amount` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bilty_no` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `warehouse` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `unit` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `batch_no` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `expiry` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pur_qty` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `price` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `expense_amount` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `discount` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `exp_unit` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dis_amount` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `due_date` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `s_party` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `transporter` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sales_price` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sales_qty` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bonus_qty` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pur_price` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sale_price` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sale_qty` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `book` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `previous_balance` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cartage` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `grand_total` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `amount_paid` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `balance_amount` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `qty_total` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dis_total` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `amount_total` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_method` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `account` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `previous_customer_id` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `previous_customer_debit` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `previous_customer_credit` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `avail_stock` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `previous_stock` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `invoice_no` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `freight` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sales_tax` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ad_sales_tax` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `banka` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `other_expensea` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bank` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `other_expense` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `freighta` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sales_taxa` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ad_sales_taxa` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pr_item` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `purchase_invoice` WRITE;
/*!40000 ALTER TABLE `purchase_invoice` DISABLE KEYS */;
INSERT INTO `purchase_invoice` VALUES (12,'PI-7911','1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'900',NULL,'34','2023-09-13',NULL,NULL,'1','1',NULL,'2023-09-13 07:00:00','2023-09-13 18:38:27','JAR',NULL,NULL,'10',NULL,NULL,'10','0.00','100',NULL,NULL,NULL,NULL,NULL,NULL,'100',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'10','100','1100.7',NULL,NULL,NULL,NULL,NULL,NULL,'10','547139','0.00','0.3','22',NULL,NULL,'0.00','0',NULL,NULL,NULL,'1');
/*!40000 ALTER TABLE `purchase_invoice` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `receipt_vouchers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `receipt_vouchers` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `unique_id` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `ref_no` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company_ref` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sales_officer` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `s-party` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `invoice_no` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remark` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `narration` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cheque_no` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cheque_date` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cash_bank` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `amount` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `amount_total` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `receipt_vouchers` WRITE;
/*!40000 ALTER TABLE `receipt_vouchers` DISABLE KEYS */;
INSERT INTO `receipt_vouchers` VALUES (1,'RV8997','23','2023-09-08','1',NULL,'1',NULL,'3','NO Remarks','testing','21','2023-09-07','1','1000.00','1000','2023-09-08 10:02:20','2023-09-08 10:02:20'),(2,'RV8997','23','2023-09-08','1',NULL,'1',NULL,NULL,'NO Remarks',NULL,NULL,NULL,NULL,'0.00','1000','2023-09-08 10:02:20','2023-09-08 10:02:20'),(3,'RV2906','32','2023-09-13','1',NULL,'1',NULL,'49',NULL,'1212','21','2023-09-13','1','1000.00','1000','2023-09-13 18:19:18','2023-09-13 18:19:18'),(4,'RV2906','32','2023-09-13','1',NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0.00','1000','2023-09-13 18:19:18','2023-09-13 18:19:18'),(5,'RV6284',NULL,'2023-09-13','1',NULL,'1',NULL,'51',NULL,'testing','21','2023-09-13','2','1000.00','1000','2023-09-13 18:28:25','2023-09-13 18:28:25'),(6,'RV6284',NULL,'2023-09-13','1',NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0.00','1000','2023-09-13 18:28:25','2023-09-13 18:28:25');
/*!40000 ALTER TABLE `receipt_vouchers` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `role_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role_has_permissions` (
  `permission_id` bigint(20) unsigned NOT NULL,
  `role_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`role_id`),
  KEY `role_has_permissions_role_id_foreign` (`role_id`),
  CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `role_has_permissions` WRITE;
/*!40000 ALTER TABLE `role_has_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `role_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roles` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `roles_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `sales_officer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sales_officer` (
  `sales_officer_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `sales_officer_name` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone_number` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`sales_officer_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `sales_officer` WRITE;
/*!40000 ALTER TABLE `sales_officer` DISABLE KEYS */;
INSERT INTO `sales_officer` VALUES (1,'Azhar  (Sales Officer) 1','03112495175','m.azharalamjawaid@gmail.com','2023-09-08 06:26:34','2023-09-08 06:26:34'),(2,'Azhar  (Sales Officer) 2','03112495175','m.azharalamjawaid@gmail.com','2023-09-08 06:26:47','2023-09-08 06:26:47');
/*!40000 ALTER TABLE `sales_officer` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `sell_invoice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sell_invoice` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `unique_id` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `rate_type` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `vehicle_no` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `crate_type` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `crate_qty` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `hen_qty` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gross_weight` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `actual_rate` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `feed_cut` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mor_cut` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `crate_cut` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `avg` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `n_weight` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `rate_diff` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `rate` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `amount` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sales_officer` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remark` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pkr_amount` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bilty_no` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `warehouse` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `unit` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `batch_no` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `expiry` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pur_qty` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `price` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `expense_amount` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `discount` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dis_amount` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `exp_unit` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `due_date` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `s_party` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `transporter` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sales_price` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sales_qty` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bonus_qty` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `item` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pur_price` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sale_price` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sale_qty` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `book` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `previous_balance` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cartage` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `grand_total` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `amount_paid` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `balance_amount` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `previous_balance_amount` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `qty_total` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dis_total` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `amount_total` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `account` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cash_method` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `previous_stock` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pr_item` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `return_qty` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `sell_invoice` WRITE;
/*!40000 ALTER TABLE `sell_invoice` DISABLE KEYS */;
INSERT INTO `sell_invoice` VALUES (51,'SI-567',NULL,'2023-09-13 18:17:56','2023-09-13 18:28:25',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'900','1',NULL,'2023-09-13',NULL,NULL,'1','1',NULL,'JAR',NULL,NULL,NULL,NULL,NULL,'10','100','0.00',NULL,NULL,'unknown',NULL,NULL,'0.00','1',NULL,'100','10','342432','57288','0','58188','3000','56188','56188','10','100','900','2',NULL,'10','1',NULL);
/*!40000 ALTER TABLE `sell_invoice` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `seller`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `seller` (
  `seller_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `company_name` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `company_email` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `credit` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `debit` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `seller_type` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_person` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_person_number` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `transporter` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reference_number` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bilty_number` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `total_records` text COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `payment_due_date` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `salesman` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`seller_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `seller` WRITE;
/*!40000 ALTER TABLE `seller` DISABLE KEYS */;
INSERT INTO `seller` VALUES (1,'psoft','m.azharalamjawaid@gmail.com','0.00','-12629.900000000001','supplier','hyderabd',NULL,'Azhar Alam',NULL,NULL,NULL,'0',NULL,'latifabad',NULL,'2023-09-08 01:45:17','2023-09-13 18:38:27'),(2,'psoft2','m.azharalamjawaid@gmail.com2','0.00','0.00','supplier','hyderabd',NULL,'Azhar Alam',NULL,NULL,NULL,'0',NULL,'latifabad',NULL,'2023-09-08 01:45:26','2023-09-08 01:45:26');
/*!40000 ALTER TABLE `seller` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `user_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone_number` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role` varchar(31) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `access` varchar(11) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'access',
  `no_records` int(11) NOT NULL DEFAULT 0,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `setup_permission` text COLLATE utf8mb4_unicode_ci DEFAULT 'all',
  `finance_permission` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `report_permission` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `product_permission` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `theme` text COLLATE utf8mb4_unicode_ci DEFAULT 'green',
  `last_seen` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `users_email_unique` (`email`),
  KEY `email_verified_at` (`email_verified_at`),
  KEY `email_verified_at_2` (`email_verified_at`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'admin',NULL,NULL,'admin','access',10,'admin','on','on','on','on',NULL,NULL,'green','2023-09-02 11:52:35',NULL,'2023-09-13 18:38:27'),(2,'admin2','m.azharalamjawaid@gmail.com','03112495175','admin','access',3,'admin','on','on','on','on',NULL,NULL,'green',NULL,'2023-09-08 18:54:14','2023-09-13 01:40:12');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `warehouse`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `warehouse` (
  `warehouse_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `warehouse_name` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `zone` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`warehouse_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `warehouse` WRITE;
/*!40000 ALTER TABLE `warehouse` DISABLE KEYS */;
INSERT INTO `warehouse` VALUES (1,'Test1','1','2023-09-08 06:25:55','2023-09-08 06:25:55'),(2,'Test2','2','2023-09-08 06:26:18','2023-09-08 06:26:18');
/*!40000 ALTER TABLE `warehouse` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `zone`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `zone` (
  `zone_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `zone_name` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`zone_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `zone` WRITE;
/*!40000 ALTER TABLE `zone` DISABLE KEYS */;
INSERT INTO `zone` VALUES (1,'Islamabad','2023-09-08 01:45:53','2023-09-08 01:45:53'),(2,'Lahore','2023-09-08 01:48:44','2023-09-08 01:48:44');
/*!40000 ALTER TABLE `zone` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

