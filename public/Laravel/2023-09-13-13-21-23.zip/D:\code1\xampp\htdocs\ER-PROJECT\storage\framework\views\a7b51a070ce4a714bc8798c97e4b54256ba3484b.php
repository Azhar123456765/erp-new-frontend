 <?php $__env->startSection('content'); ?>
<br><br><br><br><br>
<div class="container">
    <div class="row">

        <div class="col-md-12">
            <!-- DATA TABLE -->
            <h3 class="title-5 m-b-35">Invoice table</h3>
            <div class="table-data__tool">
                <div class="table-data__tool-left">

                    <button data-toggle="modal" data-target="#search-modal" class="btn btn-primary" role="button" style="background-color: black;">Filter</button>


                </div>
                <div class="table-data__tool-right">
                    <a href="/s_med_invoice" class="au-btn au-btn-icon au-btn--green au-btn--small">
                        <i class="zmdi zmdi-plus"></i>add Invoice</a>
                    <div class="rs-select2--dark rs-select2--sm rs-select2--dark2">
                        <div class="rs-select2--dark rs-select2--sm rs-select2--dark2">
                            <button href="" data-toggle="modal" data-target="#p-Invoice" class="btn btn-primary" role="button" style="background-color: #666;border:1px solid gray; outline:1px solid gray;">Export</button>
                        </div>
                    </div>
                </div>
            </div>
            <div class="table-responsive table-responsive-data2 ">
                <table class="table table-data2">
                    <thead>
                        <tr>
                            <th>S.No</th>
                            <th>Invoice No</th>
                            <th>company</th>
                            <th>Qty</th>
                            <th>Amount</th>
                            <th>Due Date</th>
                            <th>Created At</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $serial = ($sell_invoice->currentPage() - 1) * $sell_invoice->perPage() + 1;
                        ?>

                        <?php $__currentLoopData = $sell_invoice; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="tr-shadow table">
                            <td><?php echo e($serial); ?></td>
                            <td><a href="/es_med_invoice_id=<?php echo e($row->unique_id); ?>"><span class="block-email"><?php echo e($row->unique_id); ?></span></a></td>
                            <td><span><?php echo e($row->company_name); ?></span></td>
                            <td><span class="status--process" style="color: red;"><?php echo e($row->qty_total); ?></span></td>
                            <td><span class="status--process"><?php echo e($row->amount_total); ?></span></td>
                            <td class=""><?php echo e($row->due_date); ?></td>
                            <td><?php echo e($row->created_at); ?></td>
                            <td>
                                <div class="table-data-feature">
                                    <a href="/es_med_invoice_id=<?php echo e($row->unique_id); ?>" class="item" data-toggle="tooltip" data-placement="top" title="" data-original-title="Edit">
                                        <i class="zmdi zmdi-edit"></i>
                                    </a>
                                    <a href="/sale_invoice_pdf_<?php echo e($row->unique_id); ?>" class="item" data-toggle="tooltip" data-placement="top" title="" data-original-title="PDF">
                                        <i class="fa fa-solid fa-file-pdf"></i>
                                    </a>
                                </div>
                            </td>
                        </tr>
                        <div>
                            <?php echo e($sell_invoice->links()); ?>

                        </div>
                        <?php
                        $serial++;
                        ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>

            </div>
            <br>
            <div class="container">

            </div>

            <!-- END DATA TABLE -->

        </div>
    </div>
</div>








<?php $__env->stopSection(); ?>

<div class="modal fade" id="search-modal">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-body">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4>Search Invoice</h4>
                <div class="modal-body">

                    <form method="GET" action="/sale-invoice">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="username">Invoice No</label>
                            <input type="text" class="form-control " name="invoice_no" value="<?php echo e($invoice_no ?? ''); ?>">
                        </div>
                        <div class="form-group">
                            <label for="username">Company</label>
                            <select name="company" id="s" class="form-control " data-live-search="true">
                                <option></option>
                                <?php $__currentLoopData = $seller; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($row2->buyer_id); ?>" <?php echo e($row2->buyer_id == $company ? 'selected' : ''); ?>><?php echo e($row2->company_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>

                        </div>
                        <div class="form-group">
                            <label for="sales_officer">Sales Officer</label>
                            <select name="sales_officer" class="form-control " id="sales_officer" data-live-search="true">
                                <option></option>
                                <?php $__currentLoopData = $sales_officer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($row->sales_officer_id); ?>" <?php echo e($row->sales_officer_id == $sales_officer2 ? 'selected' : ''); ?>><?php echo e($row->sales_officer_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>


                        <div class="form-group">
                            <label for="username">Date</label>
                            <input type="date" class="form-control " name="date" value="<?php echo e($date ?? ''); ?>">
                            <input type="hidden" name="check" value="1">
                        </div>

                        <button type="submit" class="btn btn-primary" id="btn">Submit</button>

                    </form>

                </div>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\code1\xampp\htdocs\ER-PROJECT\resources\views/invoice/view_sale_invoice.blade.php ENDPATH**/ ?>