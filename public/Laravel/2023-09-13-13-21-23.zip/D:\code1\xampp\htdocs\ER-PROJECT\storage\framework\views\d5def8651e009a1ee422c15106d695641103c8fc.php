 <?php $__env->startSection('content'); ?>
<br>
<style>
    @media (max-width: 755px) {

        .container {
            width: 100% !important;

        }


    }

    .container {
        width: 50%;
    }
</style>
<div class="container">

    <form action="/organization" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php $__currentLoopData = $organization; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <div class="form-group">
            <label for="">Organization Name</label>
            <input type="text" name="name" id="company" class="form-control" placeholder="" aria-describedby="helpId" value="<?php echo e($row->organization_name); ?>" required>
        </div>

        <div class="form-group">
            <label for="">Organization address</label>
            <br>
            <textarea name="address" id="" cols="78" rows="3" style="border: 1px solid lightgray; width: 100%;" required><?php echo e($row->address); ?></textarea>
        </div>
        <div class="form-group">
            <div class="row">
                <div class="col">
                    <label for="">Phone Number</label>
                    <input type="number" name="phone_number" id="email" class="form-control" placeholder="" aria-describedby="helpId" value="<?php echo e($row->phone_number); ?>" required>
                </div>
                <div class="col">
                    <label for="">Email address</label>
                    <input type="email" name="email" id="email" class="form-control" placeholder="" aria-describedby="helpId" value="<?php echo e($row->email); ?>" required>

                </div>
            </div>
        </div>
        <div class="form-group">
            <label for="">Organization Logo </label>
            <div class="img" style="    border: 1px solid lightgray;">

                <input style="    border: none;" type="file" name="logo" id="email" class="form-control" placeholder="" aria-describedby="helpId">
                <input style="    border: none;" type="hidden" name="old_logo" id="email" class="form-control" placeholder="" aria-describedby="helpId" value="<?php echo e($row->logo); ?>">

                <?php $__errorArgs = ['logo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <h5 id="emailHelpId" style="color:red;">
                    <?php echo e($message); ?>!
                </h5>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <div class="right" style="    margin-left: 74%;
    margin-top: -5%;">
                    <a href="<?php echo e($row->logo); ?>" target="__blank" style="display: flex;">
                        <img src="<?php echo e($row->logo); ?>" alt="Logo" class="float-end" width="190px" height="180px">
                    </a>
                </div>
            </div>

        </div>
        <!-- <div class="form-group">
            <label for="">Choose text color</label>
            <input type="color" name="theme_color" id="text_color" class="form-control" placeholder="" aria-describedby="helpId" style="width: 25%;" value="<?php echo e($row->theme_color); ?>" required>

        </div> -->

        <br>

        <button type="submit" class="btn btn-success btn-sm">
            Submit
        </button>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </form>

</div>




<script>
    //     $('#text_color').on('change',function(){


    //         $.ajax({
    //     url: '/customize-form',
    //     type: 'POST',
    //     data: {
    //         theme_color: $("#text_color").val()
    //     },  
    //     success: function(response) {



    //     },
    //     error: function(xhr, status, error) {
    //       console.log(error);
    //     }
    //   });


    //     })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\code1\xampp\htdocs\ER-PROJECT\resources\views/customize.blade.php ENDPATH**/ ?>