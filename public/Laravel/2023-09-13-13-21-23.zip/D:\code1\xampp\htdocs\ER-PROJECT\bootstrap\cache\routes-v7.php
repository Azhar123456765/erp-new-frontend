<?php

/*
|--------------------------------------------------------------------------
| Load The Cached Routes
|--------------------------------------------------------------------------
|
| Here we will decode and unserialize the RouteCollection instance that
| holds all of the route information for an application. This allows
| us to instantaneously load the entire route map into the router.
|
*/

app('router')->setCompiledRoutes(
    array (
  'compiled' => 
  array (
    0 => false,
    1 => 
    array (
      '/sanctum/csrf-cookie' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::gk0yAQSMoBcGbEBD',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/user' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::5eRL650bNGdBuGcK',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/get' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::i35WtFQDQ8VW5LBE',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::i4niUTMdQrxUY1GB',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::XLsLOCh4jMGA9W4Q',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/403' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ykMpjfkGrly2ZYMR',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/organization' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::rEA8XuUkOeuDn77s',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::QCPTpF9gvKc9t9TE',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/users' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::6uPVlW7H7B78ShAo',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/add-user' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ZIvnxVLsVN5AiXbK',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/add_user_form' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::pEHWIdo1InwhCnak',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/warehouse' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::cWjDR7UzHiJ2e9h2',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/add_warehouse' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::qtzuEVIEcFGAgpJ8',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/zone' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::OFMklsMG0j8SkyU7',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/add_zone' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::YaKW5KqIKOrRDsWr',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/sales_officer' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::s9X95CGQdBgl4zMj',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/add_sales_officer' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::e1smlU3K8PRfxsgx',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/buyers' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::3XJFwYaAEHvzD6Rx',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/add-buyer' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::CCmD9xbAoshNugTR',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/sellers' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::RcmFe6dmtYCCD3jG',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/add-seller' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::4VWJvFuYPKvAcbwI',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/add_buyer_form' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::kvRxLa2uAnQiSHpJ',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/add_seller_form' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::pr5dv12PA3Pri2Tr',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/get-data/account' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::8aCGJFlOuvghSVvO',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/add_account' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ckbRg9mdxfifPGtF',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/p_voucher' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::uQxJXzXZDTQwOwDS',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/p_voucher_form' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::D6iTQBiNg4xs8pZe',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/r_voucher' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::XktQXIkAIIkKjoEH',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/r_voucher_form' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::BRKGWR8TS5ypkpB7',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/get-data' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::X1wClXJcRVulrke2',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/sale-invoice' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::G0xi8lQd0KYTOZQJ',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/purchase-invoice' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::XdBJyLoVmyjiWv8M',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/s_med_invoice' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::xWYxzz1VcAgJY57a',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/s_med_invoice_form' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::lzO0mVkjUTYzxbOk',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/p_med_invoice' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::hV7qZiQ9K2kyuKbr',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/p_med_invoice_form' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::8prvAzVpjN9gwGFW',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/product_category' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::GcqIRcrVxRzRJZ7r',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/add_product_category' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::3JA86f4GwBfrOMNO',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/add_product_sub_category' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::R8NqQ4I87l3x09PY',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/product_company' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::qozoLAmsYrcddItn',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/add_product_company' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::v5jTXv2CoMlmFyPC',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/product_type' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::2Zf6QmoPaED6OeUP',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/add_product_type' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::LdbBl6LVVUANbsGD',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/products' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::MzfiKfBg09BX7WhS',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/add_product_form' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::v5AKiq81DtwXLTwg',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/pdf' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::EJRTPoGQzdxSVYqR',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/gen-led' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::DUYS46Ufr3MEwGgy',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/cus-led' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::MXATi3slon6zuHIE',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/profit-led' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::pfnAh2fpZi3tD5Ws',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/stock-report' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ipYsa0Gh08U5jNmf',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/customize-form' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::xTAQg3h3UBEK0oao',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/login-check' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::3DXf4pSz4fV4CV2s',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/user-access' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::pYbsVBdTybZS0jcr',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/logout' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::mYQtMbYnrjs2HrbY',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/get_week_data' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::0ZgAInkwz57AJX5V',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
    ),
    2 => 
    array (
      0 => '{^(?|/a(?|pi/update/([^/]++)(*:30)|ccount_account\\=([^/]++)(*:61))|/e(?|dit(?|\\-user\\-([^/]++)(*:96)|_(?|user_form\\-([^/]++)(*:126)|warehouse([^/]++)(*:151)|zone([^/]++)(*:171)|s(?|ales_officer([^/]++)(*:203)|eller(?|([^/]++)(*:227)|_form(*:240)))|buyer(?|([^/]++)(*:266)|_form(*:279))|account([^/]++)(*:303)|product(?|_(?|c(?|ategory([^/]++)(*:344)|ompany([^/]++)(*:366))|sub_category([^/]++)(*:395)|type([^/]++)(*:415))|([^/]++)(*:432))))|p_(?|voucher_(?|id\\=([^/]++)(*:471)|form_id\\=([^/]++)(*:496))|med_invoice_(?|id\\=([^/]++)(*:532)|form_id\\=([^/]++)(*:557)))|r_voucher_(?|id\\=([^/]++)(*:592)|form_id\\=([^/]++)(*:617))|s_med_invoice_(?|id\\=([^/]++)(*:655)|form_id\\=([^/]++)(*:680)))|/user(?|\\-r(?|ecords\\-([^/]++)(*:720)|ights\\-([^/]++)(*:743))|_right_form\\-([^/]++)(*:773))|/view(?|\\-(?|buyer([^/]++)(*:808)|seller([^/]++)(*:830))|_single_(?|buyer([^/]++)(*:863)|seller([^/]++)(*:885)))|/r(?|s_med_invoice_(?|id\\=([^/]++)(*:929)|form_id\\=([^/]++)(*:954))|p_med_invoice_(?|id\\=([^/]++)(*:992)|form_id\\=([^/]++)(*:1017)))|/p(?|df_(?|field\\=([^/]++)(*:1054)|limit([^/]++)(*:1076))|urchase_invoice_pdf_([^/]++)(*:1114))|/sale_invoice_pdf_([^/]++)(*:1150))/?$}sDu',
    ),
    3 => 
    array (
      30 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::2L2FRyZI0miwDdnZ',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      61 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::LcK0pfZVeci5zFWi',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      96 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Jf6Jq8JLA0xYqw24',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      126 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ckKR21ppTT3TL7VX',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      151 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::fIaO66ucyVALVZaD',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      171 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::61mcqAmTuSBJpfRe',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      203 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::PWQYuQGqjL3ZdkJ1',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      227 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::U2WI9diuG4v2uXP3',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      240 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::0xZ9MnhBZZhqm35X',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      266 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::LiIwem0zByUeCGnp',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      279 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::VPO5V643X1i2iLe0',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      303 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::s9uJid5OhDT36Ksg',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      344 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::nGAxdDYlVoEVr5zt',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      366 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::gqK2qwzYf5uo1mUL',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      395 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::TPWQTbSIYBNTSlJM',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      415 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::rRkxjoqu46NT7EF0',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      432 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::r6ErZfFBGqc5h1ct',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      471 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::RrR96le2oiDenre4',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      496 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::42GU2UMlfzsLNOAs',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      532 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::a6uPkOqB2MLvQzy7',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      557 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::fOgm3Xd3OwMTfnbv',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      592 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::1NjveeIslGor3w6S',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      617 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::8iA0smnlHEZ0QfV9',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      655 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::AShm4LDfSKBJXyBk',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      680 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::C3lKkD6O6SNaWLKX',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      720 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::GBeWmhLnogd4Z5sX',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      743 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::plgEUR5f0KDFwy41',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      773 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::wv3wEFlRWDxT09nY',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      808 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::p4CztL3xvnRGune1',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      830 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::tix50ThhkoKqaCQg',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      863 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::1PSjc16uFhh1vUS5',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      885 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::I6bn20BctnpOPvNk',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      929 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::yCXWV2AdT1MbC7cS',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      954 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::TMDM7E9Th1LTmNlM',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      992 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::xjkfxZr4uioMySuM',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1017 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::96Nwp6npzUg1OjWh',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1054 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::MtLRsz5N8XVdE1lT',
          ),
          1 => 
          array (
            0 => 'view',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1076 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::pkIhpG3iry0L2Ble',
          ),
          1 => 
          array (
            0 => 'view',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1114 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::AfiHzoJYvRhBtQFY',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1150 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ShYjZQNWXEzyrat5',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => NULL,
          1 => NULL,
          2 => NULL,
          3 => NULL,
          4 => false,
          5 => false,
          6 => 0,
        ),
      ),
    ),
    4 => NULL,
  ),
  'attributes' => 
  array (
    'generated::gk0yAQSMoBcGbEBD' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'sanctum/csrf-cookie',
      'action' => 
      array (
        'uses' => 'Laravel\\Sanctum\\Http\\Controllers\\CsrfCookieController@show',
        'controller' => 'Laravel\\Sanctum\\Http\\Controllers\\CsrfCookieController@show',
        'namespace' => NULL,
        'prefix' => 'sanctum',
        'where' => 
        array (
        ),
        'middleware' => 
        array (
          0 => 'web',
        ),
        'as' => 'generated::gk0yAQSMoBcGbEBD',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::5eRL650bNGdBuGcK' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/user',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:297:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:79:"function (\\Illuminate\\Http\\Request $request) {
    return $request->user();
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"000000005c5bd2a7000000002da9f9f0";}";s:4:"hash";s:44:"K9IH8pwyVpzc0pAQhAh5z1ecBAYGWKBaDSdNh0cZNys=";}}',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::5eRL650bNGdBuGcK',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::i35WtFQDQ8VW5LBE' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/get',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\api\\userController@index',
        'controller' => 'App\\Http\\Controllers\\api\\userController@index',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::i35WtFQDQ8VW5LBE',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::i4niUTMdQrxUY1GB' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\api\\userController@store',
        'controller' => 'App\\Http\\Controllers\\api\\userController@store',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::i4niUTMdQrxUY1GB',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::2L2FRyZI0miwDdnZ' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/update/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\api\\userController@update',
        'controller' => 'App\\Http\\Controllers\\api\\userController@update',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::2L2FRyZI0miwDdnZ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::XLsLOCh4jMGA9W4Q' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '/',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\maincontroller@viewhome',
        'controller' => 'App\\Http\\Controllers\\maincontroller@viewhome',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::XLsLOCh4jMGA9W4Q',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ykMpjfkGrly2ZYMR' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '403',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:260:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:42:"function () {
    return \\view(\'403\');
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"000000005c5bd2bd000000002da9f9f0";}";s:4:"hash";s:44:"IdxBvmRN1OfndEvCeIxyhgZ8nvtveg4d/aaBVq7po/c=";}}',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::ykMpjfkGrly2ZYMR',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::rEA8XuUkOeuDn77s' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'organization',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'roleAuth',
          2 => 'userAuth',
          3 => 'setupPermission',
        ),
        'uses' => 'App\\Http\\Controllers\\OrganizationController@index',
        'controller' => 'App\\Http\\Controllers\\OrganizationController@index',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::rEA8XuUkOeuDn77s',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::QCPTpF9gvKc9t9TE' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'organization',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'roleAuth',
          2 => 'userAuth',
          3 => 'setupPermission',
        ),
        'uses' => 'App\\Http\\Controllers\\OrganizationController@store',
        'controller' => 'App\\Http\\Controllers\\OrganizationController@store',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::QCPTpF9gvKc9t9TE',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::6uPVlW7H7B78ShAo' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'users',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'roleAuth',
          2 => 'userAuth',
          3 => 'setupPermission',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@index',
        'controller' => 'App\\Http\\Controllers\\UserController@index',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::6uPVlW7H7B78ShAo',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ZIvnxVLsVN5AiXbK' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'add-user',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'roleAuth',
          2 => 'userAuth',
          3 => 'setupPermission',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@create',
        'controller' => 'App\\Http\\Controllers\\UserController@create',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::ZIvnxVLsVN5AiXbK',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::pEHWIdo1InwhCnak' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'add_user_form',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'roleAuth',
          2 => 'userAuth',
          3 => 'setupPermission',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@store',
        'controller' => 'App\\Http\\Controllers\\UserController@store',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::pEHWIdo1InwhCnak',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Jf6Jq8JLA0xYqw24' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'edit-user-{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'roleAuth',
          2 => 'userAuth',
          3 => 'setupPermission',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@edit',
        'controller' => 'App\\Http\\Controllers\\UserController@edit',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::Jf6Jq8JLA0xYqw24',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ckKR21ppTT3TL7VX' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'edit_user_form-{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'roleAuth',
          2 => 'userAuth',
          3 => 'setupPermission',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@update',
        'controller' => 'App\\Http\\Controllers\\UserController@update',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::ckKR21ppTT3TL7VX',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::GBeWmhLnogd4Z5sX' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'user-records-{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'roleAuth',
          2 => 'userAuth',
          3 => 'setupPermission',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@user_records',
        'controller' => 'App\\Http\\Controllers\\UserController@user_records',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::GBeWmhLnogd4Z5sX',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::plgEUR5f0KDFwy41' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'user-rights-{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'roleAuth',
          2 => 'userAuth',
          3 => 'setupPermission',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@user_rights',
        'controller' => 'App\\Http\\Controllers\\UserController@user_rights',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::plgEUR5f0KDFwy41',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::wv3wEFlRWDxT09nY' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'user_right_form-{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'roleAuth',
          2 => 'userAuth',
          3 => 'setupPermission',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@user_right_form',
        'controller' => 'App\\Http\\Controllers\\UserController@user_right_form',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::wv3wEFlRWDxT09nY',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::cWjDR7UzHiJ2e9h2' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'warehouse',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'userAuth',
          2 => 'setupPermission',
        ),
        'uses' => 'App\\Http\\Controllers\\maincontroller@warehouse',
        'controller' => 'App\\Http\\Controllers\\maincontroller@warehouse',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::cWjDR7UzHiJ2e9h2',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::qtzuEVIEcFGAgpJ8' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'add_warehouse',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'userAuth',
          2 => 'setupPermission',
        ),
        'uses' => 'App\\Http\\Controllers\\maincontroller@add_warehouse',
        'controller' => 'App\\Http\\Controllers\\maincontroller@add_warehouse',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::qtzuEVIEcFGAgpJ8',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::fIaO66ucyVALVZaD' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'edit_warehouse{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'userAuth',
          2 => 'setupPermission',
        ),
        'uses' => 'App\\Http\\Controllers\\maincontroller@edit_warehouse',
        'controller' => 'App\\Http\\Controllers\\maincontroller@edit_warehouse',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::fIaO66ucyVALVZaD',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::OFMklsMG0j8SkyU7' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'zone',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'userAuth',
          2 => 'setupPermission',
        ),
        'uses' => 'App\\Http\\Controllers\\maincontroller@zone',
        'controller' => 'App\\Http\\Controllers\\maincontroller@zone',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::OFMklsMG0j8SkyU7',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::YaKW5KqIKOrRDsWr' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'add_zone',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'userAuth',
          2 => 'setupPermission',
        ),
        'uses' => 'App\\Http\\Controllers\\maincontroller@add_zone',
        'controller' => 'App\\Http\\Controllers\\maincontroller@add_zone',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::YaKW5KqIKOrRDsWr',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::61mcqAmTuSBJpfRe' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'edit_zone{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'userAuth',
          2 => 'setupPermission',
        ),
        'uses' => 'App\\Http\\Controllers\\maincontroller@edit_zone',
        'controller' => 'App\\Http\\Controllers\\maincontroller@edit_zone',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::61mcqAmTuSBJpfRe',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::s9X95CGQdBgl4zMj' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'sales_officer',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'userAuth',
          2 => 'setupPermission',
        ),
        'uses' => 'App\\Http\\Controllers\\maincontroller@sales_officer',
        'controller' => 'App\\Http\\Controllers\\maincontroller@sales_officer',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::s9X95CGQdBgl4zMj',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::e1smlU3K8PRfxsgx' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'add_sales_officer',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'userAuth',
          2 => 'setupPermission',
        ),
        'uses' => 'App\\Http\\Controllers\\maincontroller@add_sales_officer',
        'controller' => 'App\\Http\\Controllers\\maincontroller@add_sales_officer',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::e1smlU3K8PRfxsgx',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::PWQYuQGqjL3ZdkJ1' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'edit_sales_officer{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'userAuth',
          2 => 'setupPermission',
        ),
        'uses' => 'App\\Http\\Controllers\\maincontroller@edit_sales_officer',
        'controller' => 'App\\Http\\Controllers\\maincontroller@edit_sales_officer',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::PWQYuQGqjL3ZdkJ1',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::LiIwem0zByUeCGnp' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'edit_buyer{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'userAuth',
          2 => 'setupPermission',
        ),
        'uses' => 'App\\Http\\Controllers\\maincontroller@view_edit_buyer',
        'controller' => 'App\\Http\\Controllers\\maincontroller@view_edit_buyer',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::LiIwem0zByUeCGnp',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::3XJFwYaAEHvzD6Rx' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'buyers',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'userAuth',
          2 => 'setupPermission',
        ),
        'uses' => 'App\\Http\\Controllers\\maincontroller@view_buyers',
        'controller' => 'App\\Http\\Controllers\\maincontroller@view_buyers',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::3XJFwYaAEHvzD6Rx',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::CCmD9xbAoshNugTR' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'add-buyer',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'userAuth',
          2 => 'setupPermission',
        ),
        'uses' => 'App\\Http\\Controllers\\maincontroller@view_add_buyer',
        'controller' => 'App\\Http\\Controllers\\maincontroller@view_add_buyer',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::CCmD9xbAoshNugTR',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::p4CztL3xvnRGune1' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'view-buyer{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'userAuth',
          2 => 'setupPermission',
        ),
        'uses' => 'App\\Http\\Controllers\\maincontroller@view_single_buyer',
        'controller' => 'App\\Http\\Controllers\\maincontroller@view_single_buyer',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::p4CztL3xvnRGune1',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::1PSjc16uFhh1vUS5' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'view_single_buyer{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'userAuth',
          2 => 'setupPermission',
        ),
        'uses' => 'App\\Http\\Controllers\\maincontroller@view_single_buyer',
        'controller' => 'App\\Http\\Controllers\\maincontroller@view_single_buyer',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::1PSjc16uFhh1vUS5',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::U2WI9diuG4v2uXP3' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'edit_seller{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'userAuth',
          2 => 'setupPermission',
        ),
        'uses' => 'App\\Http\\Controllers\\maincontroller@view_edit_seller',
        'controller' => 'App\\Http\\Controllers\\maincontroller@view_edit_seller',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::U2WI9diuG4v2uXP3',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::RcmFe6dmtYCCD3jG' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'sellers',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'userAuth',
          2 => 'setupPermission',
        ),
        'uses' => 'App\\Http\\Controllers\\maincontroller@view_sellers',
        'controller' => 'App\\Http\\Controllers\\maincontroller@view_sellers',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::RcmFe6dmtYCCD3jG',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::4VWJvFuYPKvAcbwI' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'add-seller',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'userAuth',
          2 => 'setupPermission',
        ),
        'uses' => 'App\\Http\\Controllers\\maincontroller@view_add_seller',
        'controller' => 'App\\Http\\Controllers\\maincontroller@view_add_seller',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::4VWJvFuYPKvAcbwI',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::tix50ThhkoKqaCQg' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'view-seller{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'userAuth',
          2 => 'setupPermission',
        ),
        'uses' => 'App\\Http\\Controllers\\maincontroller@view_single_seller',
        'controller' => 'App\\Http\\Controllers\\maincontroller@view_single_seller',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::tix50ThhkoKqaCQg',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::I6bn20BctnpOPvNk' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'view_single_seller{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'userAuth',
          2 => 'setupPermission',
        ),
        'uses' => 'App\\Http\\Controllers\\maincontroller@view_single_seller',
        'controller' => 'App\\Http\\Controllers\\maincontroller@view_single_seller',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::I6bn20BctnpOPvNk',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::kvRxLa2uAnQiSHpJ' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'add_buyer_form',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'userAuth',
          2 => 'setupPermission',
        ),
        'uses' => 'App\\Http\\Controllers\\maincontroller@add_buyer_form',
        'controller' => 'App\\Http\\Controllers\\maincontroller@add_buyer_form',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::kvRxLa2uAnQiSHpJ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::VPO5V643X1i2iLe0' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'edit_buyer_form',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'userAuth',
          2 => 'setupPermission',
        ),
        'uses' => 'App\\Http\\Controllers\\maincontroller@edit_buyer_form',
        'controller' => 'App\\Http\\Controllers\\maincontroller@edit_buyer_form',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::VPO5V643X1i2iLe0',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::pr5dv12PA3Pri2Tr' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'add_seller_form',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'userAuth',
          2 => 'setupPermission',
        ),
        'uses' => 'App\\Http\\Controllers\\maincontroller@add_seller_form',
        'controller' => 'App\\Http\\Controllers\\maincontroller@add_seller_form',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::pr5dv12PA3Pri2Tr',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::0xZ9MnhBZZhqm35X' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'edit_seller_form',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'userAuth',
          2 => 'setupPermission',
        ),
        'uses' => 'App\\Http\\Controllers\\maincontroller@edit_seller_form',
        'controller' => 'App\\Http\\Controllers\\maincontroller@edit_seller_form',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::0xZ9MnhBZZhqm35X',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::LcK0pfZVeci5zFWi' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'account_account={id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'userAuth',
          2 => 'setupPermission',
        ),
        'uses' => 'App\\Http\\Controllers\\maincontroller@account',
        'controller' => 'App\\Http\\Controllers\\maincontroller@account',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::LcK0pfZVeci5zFWi',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::8aCGJFlOuvghSVvO' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'get-data/account',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'userAuth',
          2 => 'setupPermission',
        ),
        'uses' => 'App\\Http\\Controllers\\maincontroller@get_data_account',
        'controller' => 'App\\Http\\Controllers\\maincontroller@get_data_account',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::8aCGJFlOuvghSVvO',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ckbRg9mdxfifPGtF' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'add_account',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'userAuth',
          2 => 'setupPermission',
        ),
        'uses' => 'App\\Http\\Controllers\\maincontroller@add_account',
        'controller' => 'App\\Http\\Controllers\\maincontroller@add_account',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::ckbRg9mdxfifPGtF',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::s9uJid5OhDT36Ksg' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'edit_account{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'userAuth',
          2 => 'setupPermission',
        ),
        'uses' => 'App\\Http\\Controllers\\maincontroller@edit_account',
        'controller' => 'App\\Http\\Controllers\\maincontroller@edit_account',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::s9uJid5OhDT36Ksg',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::uQxJXzXZDTQwOwDS' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'p_voucher',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'userAuth',
          2 => 'financePermission',
        ),
        'uses' => 'App\\Http\\Controllers\\PaymentVoucherController@create',
        'controller' => 'App\\Http\\Controllers\\PaymentVoucherController@create',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::uQxJXzXZDTQwOwDS',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::D6iTQBiNg4xs8pZe' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'p_voucher_form',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'userAuth',
          2 => 'financePermission',
        ),
        'uses' => 'App\\Http\\Controllers\\PaymentVoucherController@store',
        'controller' => 'App\\Http\\Controllers\\PaymentVoucherController@store',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::D6iTQBiNg4xs8pZe',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::RrR96le2oiDenre4' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'ep_voucher_id={id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'userAuth',
          2 => 'financePermission',
        ),
        'uses' => 'App\\Http\\Controllers\\PaymentVoucherController@edit',
        'controller' => 'App\\Http\\Controllers\\PaymentVoucherController@edit',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::RrR96le2oiDenre4',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::42GU2UMlfzsLNOAs' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'ep_voucher_form_id={id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'userAuth',
          2 => 'financePermission',
        ),
        'uses' => 'App\\Http\\Controllers\\PaymentVoucherController@update',
        'controller' => 'App\\Http\\Controllers\\PaymentVoucherController@update',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::42GU2UMlfzsLNOAs',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::XktQXIkAIIkKjoEH' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'r_voucher',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'userAuth',
          2 => 'financePermission',
        ),
        'uses' => 'App\\Http\\Controllers\\ReceiptVoucherController@index',
        'controller' => 'App\\Http\\Controllers\\ReceiptVoucherController@index',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::XktQXIkAIIkKjoEH',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::BRKGWR8TS5ypkpB7' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'r_voucher_form',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'userAuth',
          2 => 'financePermission',
        ),
        'uses' => 'App\\Http\\Controllers\\ReceiptVoucherController@store',
        'controller' => 'App\\Http\\Controllers\\ReceiptVoucherController@store',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::BRKGWR8TS5ypkpB7',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::X1wClXJcRVulrke2' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'get-data',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'userAuth',
          2 => 'financePermission',
        ),
        'uses' => 'App\\Http\\Controllers\\ReceiptVoucherController@get_data',
        'controller' => 'App\\Http\\Controllers\\ReceiptVoucherController@get_data',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::X1wClXJcRVulrke2',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::1NjveeIslGor3w6S' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'er_voucher_id={id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'userAuth',
          2 => 'financePermission',
        ),
        'uses' => 'App\\Http\\Controllers\\ReceiptVoucherController@edit',
        'controller' => 'App\\Http\\Controllers\\ReceiptVoucherController@edit',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::1NjveeIslGor3w6S',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::8iA0smnlHEZ0QfV9' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'er_voucher_form_id={id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'userAuth',
          2 => 'financePermission',
        ),
        'uses' => 'App\\Http\\Controllers\\ReceiptVoucherController@update',
        'controller' => 'App\\Http\\Controllers\\ReceiptVoucherController@update',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::8iA0smnlHEZ0QfV9',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::G0xi8lQd0KYTOZQJ' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'sale-invoice',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'userAuth',
          2 => 'financePermission',
        ),
        'uses' => 'App\\Http\\Controllers\\SaleInvoiceController@index',
        'controller' => 'App\\Http\\Controllers\\SaleInvoiceController@index',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::G0xi8lQd0KYTOZQJ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::XdBJyLoVmyjiWv8M' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'purchase-invoice',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'userAuth',
          2 => 'financePermission',
        ),
        'uses' => 'App\\Http\\Controllers\\PurchaseInvoiceController@index',
        'controller' => 'App\\Http\\Controllers\\PurchaseInvoiceController@index',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::XdBJyLoVmyjiWv8M',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::xWYxzz1VcAgJY57a' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 's_med_invoice',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'userAuth',
          2 => 'financePermission',
        ),
        'uses' => 'App\\Http\\Controllers\\SaleInvoiceController@create',
        'controller' => 'App\\Http\\Controllers\\SaleInvoiceController@create',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::xWYxzz1VcAgJY57a',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::lzO0mVkjUTYzxbOk' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 's_med_invoice_form',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'userAuth',
          2 => 'financePermission',
        ),
        'uses' => 'App\\Http\\Controllers\\SaleInvoiceController@store',
        'controller' => 'App\\Http\\Controllers\\SaleInvoiceController@store',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::lzO0mVkjUTYzxbOk',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::AShm4LDfSKBJXyBk' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'es_med_invoice_id={id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'userAuth',
          2 => 'financePermission',
        ),
        'uses' => 'App\\Http\\Controllers\\SaleInvoiceController@edit',
        'controller' => 'App\\Http\\Controllers\\SaleInvoiceController@edit',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::AShm4LDfSKBJXyBk',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::C3lKkD6O6SNaWLKX' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'es_med_invoice_form_id={id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'userAuth',
          2 => 'financePermission',
        ),
        'uses' => 'App\\Http\\Controllers\\SaleInvoiceController@update',
        'controller' => 'App\\Http\\Controllers\\SaleInvoiceController@update',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::C3lKkD6O6SNaWLKX',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::yCXWV2AdT1MbC7cS' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'rs_med_invoice_id={id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'userAuth',
          2 => 'financePermission',
        ),
        'uses' => 'App\\Http\\Controllers\\SaleInvoiceController@r_edit',
        'controller' => 'App\\Http\\Controllers\\SaleInvoiceController@r_edit',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::yCXWV2AdT1MbC7cS',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::TMDM7E9Th1LTmNlM' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'rs_med_invoice_form_id={id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'userAuth',
          2 => 'financePermission',
        ),
        'uses' => 'App\\Http\\Controllers\\SaleInvoiceController@r_update',
        'controller' => 'App\\Http\\Controllers\\SaleInvoiceController@r_update',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::TMDM7E9Th1LTmNlM',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::hV7qZiQ9K2kyuKbr' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'p_med_invoice',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'userAuth',
          2 => 'financePermission',
        ),
        'uses' => 'App\\Http\\Controllers\\PurchaseInvoiceController@create',
        'controller' => 'App\\Http\\Controllers\\PurchaseInvoiceController@create',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::hV7qZiQ9K2kyuKbr',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::8prvAzVpjN9gwGFW' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'p_med_invoice_form',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'userAuth',
          2 => 'financePermission',
        ),
        'uses' => 'App\\Http\\Controllers\\PurchaseInvoiceController@store',
        'controller' => 'App\\Http\\Controllers\\PurchaseInvoiceController@store',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::8prvAzVpjN9gwGFW',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::a6uPkOqB2MLvQzy7' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'ep_med_invoice_id={id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'userAuth',
          2 => 'financePermission',
        ),
        'uses' => 'App\\Http\\Controllers\\PurchaseInvoiceController@edit',
        'controller' => 'App\\Http\\Controllers\\PurchaseInvoiceController@edit',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::a6uPkOqB2MLvQzy7',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::fOgm3Xd3OwMTfnbv' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'ep_med_invoice_form_id={id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'userAuth',
          2 => 'financePermission',
        ),
        'uses' => 'App\\Http\\Controllers\\PurchaseInvoiceController@update',
        'controller' => 'App\\Http\\Controllers\\PurchaseInvoiceController@update',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::fOgm3Xd3OwMTfnbv',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::xjkfxZr4uioMySuM' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'rp_med_invoice_id={id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'userAuth',
          2 => 'financePermission',
        ),
        'uses' => 'App\\Http\\Controllers\\PurchaseInvoiceController@r_edit',
        'controller' => 'App\\Http\\Controllers\\PurchaseInvoiceController@r_edit',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::xjkfxZr4uioMySuM',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::96Nwp6npzUg1OjWh' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'rp_med_invoice_form_id={id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'userAuth',
          2 => 'financePermission',
        ),
        'uses' => 'App\\Http\\Controllers\\PurchaseInvoiceController@r_update',
        'controller' => 'App\\Http\\Controllers\\PurchaseInvoiceController@r_update',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::96Nwp6npzUg1OjWh',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::GcqIRcrVxRzRJZ7r' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'product_category',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'userAuth',
          2 => 'productPermission',
        ),
        'uses' => 'App\\Http\\Controllers\\product@product_category',
        'controller' => 'App\\Http\\Controllers\\product@product_category',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::GcqIRcrVxRzRJZ7r',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::3JA86f4GwBfrOMNO' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'add_product_category',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'userAuth',
          2 => 'productPermission',
        ),
        'uses' => 'App\\Http\\Controllers\\product@add_product_category',
        'controller' => 'App\\Http\\Controllers\\product@add_product_category',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::3JA86f4GwBfrOMNO',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::nGAxdDYlVoEVr5zt' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'edit_product_category{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'userAuth',
          2 => 'productPermission',
        ),
        'uses' => 'App\\Http\\Controllers\\product@edit_product_category',
        'controller' => 'App\\Http\\Controllers\\product@edit_product_category',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::nGAxdDYlVoEVr5zt',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::R8NqQ4I87l3x09PY' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'add_product_sub_category',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'userAuth',
          2 => 'productPermission',
        ),
        'uses' => 'App\\Http\\Controllers\\product@add_product_sub_category',
        'controller' => 'App\\Http\\Controllers\\product@add_product_sub_category',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::R8NqQ4I87l3x09PY',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::TPWQTbSIYBNTSlJM' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'edit_product_sub_category{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'userAuth',
          2 => 'productPermission',
        ),
        'uses' => 'App\\Http\\Controllers\\product@edit_product_sub_category',
        'controller' => 'App\\Http\\Controllers\\product@edit_product_sub_category',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::TPWQTbSIYBNTSlJM',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::qozoLAmsYrcddItn' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'product_company',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'userAuth',
          2 => 'productPermission',
        ),
        'uses' => 'App\\Http\\Controllers\\product@product_company',
        'controller' => 'App\\Http\\Controllers\\product@product_company',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::qozoLAmsYrcddItn',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::v5jTXv2CoMlmFyPC' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'add_product_company',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'userAuth',
          2 => 'productPermission',
        ),
        'uses' => 'App\\Http\\Controllers\\product@add_product_company',
        'controller' => 'App\\Http\\Controllers\\product@add_product_company',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::v5jTXv2CoMlmFyPC',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::gqK2qwzYf5uo1mUL' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'edit_product_company{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'userAuth',
          2 => 'productPermission',
        ),
        'uses' => 'App\\Http\\Controllers\\product@edit_product_company',
        'controller' => 'App\\Http\\Controllers\\product@edit_product_company',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::gqK2qwzYf5uo1mUL',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::2Zf6QmoPaED6OeUP' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'product_type',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'userAuth',
          2 => 'productPermission',
        ),
        'uses' => 'App\\Http\\Controllers\\product@product_type',
        'controller' => 'App\\Http\\Controllers\\product@product_type',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::2Zf6QmoPaED6OeUP',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::LdbBl6LVVUANbsGD' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'add_product_type',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'userAuth',
          2 => 'productPermission',
        ),
        'uses' => 'App\\Http\\Controllers\\product@add_product_type',
        'controller' => 'App\\Http\\Controllers\\product@add_product_type',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::LdbBl6LVVUANbsGD',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::rRkxjoqu46NT7EF0' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'edit_product_type{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'userAuth',
          2 => 'productPermission',
        ),
        'uses' => 'App\\Http\\Controllers\\product@edit_product_type',
        'controller' => 'App\\Http\\Controllers\\product@edit_product_type',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::rRkxjoqu46NT7EF0',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::MzfiKfBg09BX7WhS' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'products',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'userAuth',
          2 => 'productPermission',
        ),
        'uses' => 'App\\Http\\Controllers\\product@view_product',
        'controller' => 'App\\Http\\Controllers\\product@view_product',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::MzfiKfBg09BX7WhS',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::v5AKiq81DtwXLTwg' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'add_product_form',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'userAuth',
          2 => 'productPermission',
        ),
        'uses' => 'App\\Http\\Controllers\\product@add_product',
        'controller' => 'App\\Http\\Controllers\\product@add_product',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::v5AKiq81DtwXLTwg',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::r6ErZfFBGqc5h1ct' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'edit_product{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'userAuth',
          2 => 'productPermission',
        ),
        'uses' => 'App\\Http\\Controllers\\product@edit_product',
        'controller' => 'App\\Http\\Controllers\\product@edit_product',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::r6ErZfFBGqc5h1ct',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::MtLRsz5N8XVdE1lT' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'pdf_field={view}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'userAuth',
          2 => 'reportPermission',
        ),
        'uses' => 'App\\Http\\Controllers\\pdfController@pdf',
        'controller' => 'App\\Http\\Controllers\\pdfController@pdf',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::MtLRsz5N8XVdE1lT',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::pkIhpG3iry0L2Ble' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'pdf_limit{view}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'userAuth',
          2 => 'reportPermission',
        ),
        'uses' => 'App\\Http\\Controllers\\pdfController@pdf_limit',
        'controller' => 'App\\Http\\Controllers\\pdfController@pdf_limit',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::pkIhpG3iry0L2Ble',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::EJRTPoGQzdxSVYqR' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'pdf',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'userAuth',
          2 => 'reportPermission',
        ),
        'uses' => 'App\\Http\\Controllers\\pdfController@test_pdf',
        'controller' => 'App\\Http\\Controllers\\pdfController@test_pdf',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::EJRTPoGQzdxSVYqR',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ShYjZQNWXEzyrat5' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'sale_invoice_pdf_{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'userAuth',
          2 => 'reportPermission',
        ),
        'uses' => 'App\\Http\\Controllers\\pdfController@sale_invoice_pdf',
        'controller' => 'App\\Http\\Controllers\\pdfController@sale_invoice_pdf',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::ShYjZQNWXEzyrat5',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::AfiHzoJYvRhBtQFY' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'purchase_invoice_pdf_{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'userAuth',
          2 => 'reportPermission',
        ),
        'uses' => 'App\\Http\\Controllers\\pdfController@purchase_invoice_pdf',
        'controller' => 'App\\Http\\Controllers\\pdfController@purchase_invoice_pdf',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::AfiHzoJYvRhBtQFY',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::DUYS46Ufr3MEwGgy' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'gen-led',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'userAuth',
          2 => 'reportPermission',
        ),
        'uses' => 'App\\Http\\Controllers\\pdfController@gen_led',
        'controller' => 'App\\Http\\Controllers\\pdfController@gen_led',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::DUYS46Ufr3MEwGgy',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::MXATi3slon6zuHIE' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'cus-led',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'userAuth',
          2 => 'reportPermission',
        ),
        'uses' => 'App\\Http\\Controllers\\pdfController@cus_led',
        'controller' => 'App\\Http\\Controllers\\pdfController@cus_led',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::MXATi3slon6zuHIE',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::pfnAh2fpZi3tD5Ws' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'profit-led',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'userAuth',
          2 => 'reportPermission',
        ),
        'uses' => 'App\\Http\\Controllers\\pdfController@profit_rep',
        'controller' => 'App\\Http\\Controllers\\pdfController@profit_rep',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::pfnAh2fpZi3tD5Ws',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ipYsa0Gh08U5jNmf' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'stock-report',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'userAuth',
          2 => 'reportPermission',
        ),
        'uses' => 'App\\Http\\Controllers\\pdfController@stock_rep',
        'controller' => 'App\\Http\\Controllers\\pdfController@stock_rep',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::ipYsa0Gh08U5jNmf',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::xTAQg3h3UBEK0oao' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'customize-form',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\maincontroller@customize_form',
        'controller' => 'App\\Http\\Controllers\\maincontroller@customize_form',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::xTAQg3h3UBEK0oao',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::3DXf4pSz4fV4CV2s' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'login-check',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\maincontroller@logincheck',
        'controller' => 'App\\Http\\Controllers\\maincontroller@logincheck',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::3DXf4pSz4fV4CV2s',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::pYbsVBdTybZS0jcr' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'user-access',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\maincontroller@user_acces',
        'controller' => 'App\\Http\\Controllers\\maincontroller@user_acces',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::pYbsVBdTybZS0jcr',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::mYQtMbYnrjs2HrbY' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'logout',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\maincontroller@logout',
        'controller' => 'App\\Http\\Controllers\\maincontroller@logout',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::mYQtMbYnrjs2HrbY',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::0ZgAInkwz57AJX5V' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'get_week_data',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\maincontroller@get_week_data',
        'controller' => 'App\\Http\\Controllers\\maincontroller@get_week_data',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::0ZgAInkwz57AJX5V',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
  ),
)
);
